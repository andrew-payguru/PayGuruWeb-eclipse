package za.co.payguru.util;

import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Vector;

public class Util {

	
	public static ArrayList<String> fileSBToArrayList(StringBuilder sb){
		ArrayList<String> data = new ArrayList<String>();
		if(sb==null)
			return data;
		String [] sbAr = sb.toString().split("\n"); 
		for(String line : sbAr) {
			data.add(line.trim());
		}
		return data;
	}

	public static String prefixChar(String details, char val, int totallen) {
		int len1 = details.length();
		for(int c=0;c<totallen-len1;c++) {
		  details = val + details;
		}
		return details;
	}
	
	public static String getValueAt(String details, String delim, int idx) {
		String value = "";
		int c = 0;
		StringTokenizer ts = new StringTokenizer(details,delim);
		while(ts.hasMoreTokens()) {
			String val = ts.nextToken();
			if(c==idx) {
				value = val;
				break;
			}
			c++;
		}
		return value;
	}

	public static int parseInt(String details, int defValue) {
		try {
			defValue = Integer.parseInt(details);
		}
		catch(Exception e) {
		}
		return defValue;
	}

	public static long parseLong(String details, long defValue) {
		try {
			defValue = Long.parseLong(details);
		}
		catch(Exception e) {
		}
		return defValue;
	}

	public static double parseDouble(String details, double defValue) {
		try {
			defValue = Double.parseDouble(details);
		}
		catch(Exception e) {
		}
		return defValue;
	}

	public static boolean parseBoolean(String details) {
		boolean valid = false;
		try {
		if((details.equalsIgnoreCase("true"))||(details.equalsIgnoreCase("1")))
			valid = true;
		}catch (Exception e) {
		}
		return valid;
	}



	public static String replaceRepetitions(String details, char val1, char val2) {
		Vector data = new Vector();
		StringBuffer sb = new StringBuffer();
		if(details==null||details.length()<=0) {
			details = "";
			return details;
		}
		boolean first = true;
		for(char charEntry : details.toCharArray()) {
			if(charEntry!=val1) {
				sb.append(charEntry);
				first = true;
			}else {
				if(first == true) {
					sb.append(String.valueOf(val2));
					first = false;
				}
			}
		}
			return sb.toString();
	}

	public static int countCharOccurancesInString(String str, char c) {
		int count = 0;
		try {
			for(int i=0; i < str.length(); i++) {
			  if(str.charAt(i) == c)
				count++;
			}
		}catch(Exception e) {}
		return count;
	} 
}
