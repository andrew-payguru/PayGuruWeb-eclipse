package za.co.payguru.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;

public class FileUtil {

	public static HashMap<String,String> readKeyValueFile(String filePath){
		HashMap<String,String> keyValues = new HashMap<String, String>();
		String errMsg = "";
		for(int z=0;z<1;z++) {
			File iniFile = new File(filePath);
			if((iniFile==null) || (iniFile.exists()==false) || (iniFile.isFile()==false)) {
				errMsg = "ERROR READING FILE: " + filePath;
				break;
			}
			try(
					BufferedReader br = new BufferedReader(new FileReader(iniFile))
			){
				String line = "";
				while((line = br.readLine()) != null) {
					line = line.trim();
					if(line.indexOf("//")==0)
						continue;
					String key = Util.getValueAt(line, "=", 0).trim();
					String value = Util.getValueAt(line, "=", 1).trim();
					keyValues.put(key, value);
				}
			}catch (Exception e) {
				System.out.println(e.toString());
				errMsg = "ERROR READING FILE: " + filePath;
				break;
			}
		}
		System.out.println(errMsg);
		return keyValues;
	}
}
