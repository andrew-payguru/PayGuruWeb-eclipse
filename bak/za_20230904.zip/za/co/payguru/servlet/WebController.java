package za.co.payguru.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import za.co.payguru.dao.CompanyDao;
import za.co.payguru.dao.CompanyUserDao;
import za.co.payguru.dao.ParamDao;
import za.co.payguru.dao.WebPageDao;
import za.co.payguru.dao.WebPageGroupDao;
import za.co.payguru.model.Company;
import za.co.payguru.model.CompanyUser;
import za.co.payguru.model.Param;
import za.co.payguru.model.WebPage;
import za.co.payguru.model.WebPageGroup;
import za.co.payguru.servlet.process.Process_webapp;
import za.co.payguru.servlet.process.Process_campaigns;
import za.co.payguru.servlet.process.Process_test;
import za.co.payguru.util.DBUtil;
import za.co.payguru.util.HTTPUtil;
import za.co.payguru.util.IniUtil;
import za.co.payguru.util.JSONHelper;

public class WebController extends HttpServlet{

	public final static int ERROR_CODE_SERVLET = 9001;
	public static String dbName = ""; 

	@Override
	public void init(ServletConfig servletConfig) throws ServletException {
		super.init(servletConfig);
		IniUtil ini = new IniUtil();
		dbName = ini.getValue("db");
	}


	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		String auth = req.getHeader("Authorization");
//		String credentials = auth
		String action = req.getParameter("action");
		String origincode = req.getParameter("weborigincode");
		System.out.println(action + " : " + req.getContentType());
		PrintWriter pw = resp.getWriter();
		StringBuilder sb = new StringBuilder();
		JSONObject jsonBody = JSONHelper.getJsonBody(req); 
		resp.setContentType("application/json");
		for(int z=0;z<1;z++) {
			try(
					Connection connection = DBUtil.getConnection(dbName);
			){
				Param origincodeparam = ParamDao.getParam("weborigincode", connection);
				if(origincode==null || origincode.equals(origincodeparam.getParamValue())==false) {
					sb = JSONHelper.getErrorJson("Not Permitted!");
					resp.setStatus(HTTPUtil.HTTP_UNAUTHORIZED);
					break;
				}
				String ipAddress = req.getHeader("X-FORWARDED-FOR");
				if(ipAddress==null)
					ipAddress = req.getRemoteAddr();
				System.out.println("IP ADDRESS: " + ipAddress);
				if(action==null || action.length()<=0) {
					sb = JSONHelper.getErrorJson("No Action Specified!");
					resp.setStatus(HTTPUtil.HTTP_BAD_REQUEST);
					break;
				}else {
					if(action.equals("register"))
						sb = processRegister(req,resp,jsonBody,connection);
					else if(action.equals("login"))
						sb = processLogin(req,resp,jsonBody,connection);
					else if(action.equals("getcompany"))
						sb = processGetCompany(req,resp,jsonBody,connection);
					else if(action.equals("getcompwebpages"))
						sb = processGetCompanyWebPages(req,resp,jsonBody,connection);
					else if(action.equals("getcompwebpagegroups"))
						sb = processGetCompanyWebPageGroups(req,resp,jsonBody,connection);
					else if(action.equals("getinvoicevspaymentsgraph"))
						sb = processGetInvoiceVsPaymentsGraph(req,resp,jsonBody,connection);
					else if(action.equals("createcustgroup"))
						sb = Process_campaigns.createCustomerGroup(req,resp,jsonBody,connection);
					else if(action.equals("getactivegroups"))
						sb = Process_campaigns.getGroups(req,resp,false,jsonBody,connection);
					else if(action.equals("getinactivegroups"))
						sb = Process_campaigns.getGroups(req,resp,true,jsonBody,connection);
					else if(action.equals("updategroup"))
						sb = Process_campaigns.updateGroup(req,resp,jsonBody,connection);
					else if(action.equals("searchcampaigns"))
						sb = Process_campaigns.searchCampaigns(req,resp,jsonBody,connection);
					else if(action.equals("searchcampaignitems"))
						sb = Process_campaigns.searchCampaignItems(req,resp,jsonBody,connection);
					else if(action.equals("updateCampaignItems"))
						sb = Process_campaigns.updateCampaignItems(req,resp,jsonBody,connection);
					else if(action.equals("getcampaigns"))
						sb = Process_campaigns.getCampaigns(req,resp,connection);
					else if(action.equals("campaignreport"))
						sb = Process_campaigns.processCampaignReport(req,resp,connection);
					else if(action.equals("testparams"))
						sb = Process_test.testParams(req,resp);
					else if(action.equals("testjson"))
						sb = Process_test.testJson(req,resp,jsonBody);
					else if(action.equals("test"))
						sb = Process_test.test(req,resp);
					else if(action.equals("getsalechannelinvoices"))
						sb = Process_webapp.getSaleChannelInvoices(req,resp,jsonBody,connection);
					else if(action.equals("getsalechannelinvoicedata"))
						sb = Process_webapp.getSaleChannelInvoiceData(req,resp,jsonBody,connection);
					else if(action.equals("getsalechannelinvoicesales"))
						sb = Process_webapp.getSaleChannelInvoiceSales(req,resp,jsonBody,connection);
					else if(action.equals("getsalechannelinvoicedatasales"))
						sb = Process_webapp.getSaleChannelInvoiceDataSales(req,resp,jsonBody,connection);
					else if(action.equals("getcompparam"))
						sb = Process_webapp.getCompanyParam(req,resp,jsonBody,connection);
					else if(action.equals("getcompinternals"))
						sb = Process_webapp.getCompanyInternals(req,resp,jsonBody,connection);
					else if(action.equals("getcompinternalproducts"))
						sb = Process_webapp.getCompanyInternalProducts(req,resp,jsonBody,connection);
					else if(action.equals("getcompbanks"))
						sb = Process_webapp.getCompanyBanks(req,resp,jsonBody,connection);
					else {
						sb = JSONHelper.getErrorJson("Unknown action!");
						resp.setStatus(HTTPUtil.HTTP_BAD_REQUEST);
						break;
					}

				}
			}catch (Exception e) {
				sb = JSONHelper.getErrorJson("Server Error, please report to the PayGuru team!");
				resp.setStatus(HTTPUtil.HTTP_INTERNAL_SERVLET_ERROR);
				break;
			}
		}
		pw.write(sb.toString());
		pw.close();
	}

	private StringBuilder processGetInvoiceVsPaymentsGraph(HttpServletRequest req, HttpServletResponse resp,JSONObject jsonBody, Connection connection) {
		StringBuilder sb = new StringBuilder();
		String errMsg = "";
		try {
			for(int z=0;z<1;z++) {
				Company company = CompanyDao.getCompany(JSONHelper.getIntValue(jsonBody, "compid"),connection);
				if(company==null||company.getCompId()==0) {
					errMsg = "Company ID ["+company.getCompId()+"] Does Not Exist";
					break;
				}
				
			}
		}catch (Exception e) {
			System.out.println("Server Error Process: GetInvoiceVsPaymentsGraph -> " + e.toString());
			errMsg = "Server Error";
		}
		if(errMsg.length()>0) {
			resp.setStatus(HTTPUtil.HTTP_INTERNAL_SERVLET_ERROR);
			sb = JSONHelper.getErrorJson(errMsg);
		}
		return sb;		
	}

	private StringBuilder processGetCompanyWebPageGroups(HttpServletRequest req, HttpServletResponse resp,JSONObject jsonBody, Connection connection) {
		StringBuilder sb = new StringBuilder();
		String errMsg = "";
		try {
			for(int z=0;z<1;z++) {
				Company company = CompanyDao.getCompany(JSONHelper.getIntValue(jsonBody, "compid"),connection);
				if(company==null||company.getCompId()==0) {
					errMsg = "Company ID ["+company.getCompId()+"] Does Not Exist";
					break;
				}
				ArrayList<WebPageGroup> webPageGroups = WebPageGroupDao.getCompWebPageGroups(company.getCompId(), connection);
				sb = WebPageGroupDao.getJsonWebPageGroups(webPageGroups);
			}
		}catch (Exception e) {
			System.out.println("Server Error Process: GetCompanyWebPageGroups -> " + e.toString());
			errMsg = "Server Error";
		}
		if(errMsg.length()>0) {
			resp.setStatus(HTTPUtil.HTTP_INTERNAL_SERVLET_ERROR);
			sb = JSONHelper.getErrorJson(errMsg);
		}
		return sb;
	}

	private StringBuilder processGetCompanyWebPages(HttpServletRequest req, HttpServletResponse resp, JSONObject jsonBody,Connection connection) {
		StringBuilder sb = new StringBuilder();
		String errMsg = "";
		try {
			for(int z=0;z<1;z++) {
				Company company = CompanyDao.getCompany(JSONHelper.getIntValue(jsonBody, "compid"),connection);
				if(company==null||company.getCompId()==0) {
					errMsg = "Company ID ["+company.getCompId()+"] Does Not Exist";
					break;
				}
				ArrayList<WebPage> webPages = WebPageDao.getCompWebPages(company.getCompId(), connection);
				sb = WebPageDao.getJsonWebPages(webPages);
			}
		}catch (Exception e) {
			System.out.println("Server Error Process: GetCompanyWebPages -> " + e.toString());
			errMsg = "Server Error";
		}
		if(errMsg.length()>0) {
			resp.setStatus(HTTPUtil.HTTP_INTERNAL_SERVLET_ERROR);
			sb = JSONHelper.getErrorJson(errMsg);
		}
		return sb;
	}

	private StringBuilder processGetCompany(HttpServletRequest req, HttpServletResponse resp, JSONObject jsonBody, Connection connection) {
		StringBuilder sb = new StringBuilder();
		String errMsg = "";
		try {
			for(int z=0;z<1;z++) {
				Company company = CompanyDao.getCompany(JSONHelper.getIntValue(jsonBody, "compid"),connection);
				if(company==null||company.getCompId()==0) {
					errMsg = "Company ID ["+company.getCompId()+"] Does Not Exist";
					break;
				}
				sb = CompanyDao.getJsonCompany(company);
			}
		}catch (Exception e) {
			System.out.println("Server Error Process: GetCompany -> " + e.toString());
			errMsg = "Server Error";
		}
		if(errMsg.length()>0) {
			resp.setStatus(HTTPUtil.HTTP_INTERNAL_SERVLET_ERROR);
			sb = JSONHelper.getErrorJson(errMsg);
		}
		return sb;
	}
	private StringBuilder processLogin(HttpServletRequest req, HttpServletResponse resp, JSONObject jsonBody, Connection connection) {
		StringBuilder sb = new StringBuilder();
		String errMsg = "";
		try {
			for(int z=0;z<1;z++) {

				Company company = CompanyDao.getCompany(JSONHelper.getIntValue(jsonBody, "compid"),connection);
				if(company==null||company.getCompId()==0) {
					errMsg = "Company ID ["+company.getCompId()+"] Does Not Exist";
					break;
				}
				CompanyUser companyUser = CompanyUserDao.getCompanyUserEmail(company.getCompId(), JSONHelper.getValue(jsonBody, "useremail"),connection);
				if(companyUser==null||companyUser.getCompId()==0) {
					errMsg = "Username Password Combination Incorrect!";
					break;
				}
				if(companyUser.getUserPassword().equals(JSONHelper.getValue(jsonBody, "password"))==false) {
					errMsg = "Username Password Combination Incorrect!";
					break;
				}

				sb = CompanyUserDao.getJsonCompanyUser(companyUser);
			}
		}catch (Exception e) {
			System.out.println("Server Error Process: Login -> " + e.toString());
			errMsg = "Server Error";
			resp.setStatus(HTTPUtil.HTTP_INTERNAL_SERVLET_ERROR);
		}
		if(errMsg.length()>0) {
			sb = JSONHelper.getErrorJson(errMsg);
		}
		return sb;

	}
	private StringBuilder processRegister(HttpServletRequest req, HttpServletResponse resp,	JSONObject jsonBody, Connection connection) {
		
		return null;
	}

}
