package za.co.payguru.test;

import java.sql.Date;
import java.time.LocalDate;

import za.co.payguru.util.DateUtil;

public class Test {
	public static void main(String[] args) {
		
		Date currDate = Date.valueOf("2023-08-04");
		Date toDate = Date.valueOf("2023-08-04");
		
		while(currDate.compareTo(toDate)<=0) {
			
			System.out.println(currDate);
			currDate = DateUtil.getNextDate(currDate);
		}
	}

}
