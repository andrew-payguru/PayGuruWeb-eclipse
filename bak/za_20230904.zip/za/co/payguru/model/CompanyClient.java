package za.co.payguru.model;

public class CompanyClient {
	private int compId;
	private int clientId;
	private String createDate;
	private String createTime;
	private String status;
	private String statusDate;
	private String statusTime;
	private String clientExtRef;
	public CompanyClient() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CompanyClient(int compId, int clientId, String createDate, String createTime, String status,
			String statusDate, String statusTime, String clientExtRef) {
		super();
		this.compId = compId;
		this.clientId = clientId;
		this.createDate = createDate;
		this.createTime = createTime;
		this.status = status;
		this.statusDate = statusDate;
		this.statusTime = statusTime;
		this.clientExtRef = clientExtRef;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusDate() {
		return statusDate;
	}
	public void setStatusDate(String statusDate) {
		this.statusDate = statusDate;
	}
	public String getStatusTime() {
		return statusTime;
	}
	public void setStatusTime(String statusTime) {
		this.statusTime = statusTime;
	}
	public String getClientExtRef() {
		return clientExtRef;
	}
	public void setClientExtRef(String clientExtRef) {
		this.clientExtRef = clientExtRef;
	}
	@Override
	public String toString() {
		return "CompanyClients [compId=" + compId + ", clientId=" + clientId + ", createDate=" + createDate
				+ ", createTime=" + createTime + ", status=" + status + ", statusDate=" + statusDate + ", statusTime="
				+ statusTime + ", clientExtRef=" + clientExtRef + "]";
	}
	
	
}
