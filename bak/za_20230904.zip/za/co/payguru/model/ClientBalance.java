package za.co.payguru.model;

public class ClientBalance {
	private int clientId;
	private double clientBal;
	public ClientBalance() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ClientBalance(int clientId, double clientBal) {
		super();
		this.clientId = clientId;
		this.clientBal = clientBal;
	}
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	public double getClientBal() {
		return clientBal;
	}
	public void setClientBal(double clientBal) {
		this.clientBal = clientBal;
	}
	
	
}
