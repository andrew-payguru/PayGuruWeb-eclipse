package za.co.payguru.model;

import java.sql.Date;
import java.time.LocalDate;

public class ClientInvoice {
	public static final String INVOICE_ACTIVE = "1";
	public static final String INVOICE_PENDING = "2";
	public static final String INVOICE_ERROR = "3";
	public static final String INVOICE_PAID = "4";
	public static final String SAVINGS_BALANCE_STATUS = "5";
	
	private int clientId = 0;
	private int prodId = 0;
	private int compId = 0;
	private String invNo = "";
	private double payAmt = 0;
	private double payVat = 0;
	private String payDate = "";
	private String payRef = "";
	private String payNext = "";
	private String status = "";
	private String statusDate = "";
	private String statusTime = "";
	private int batchId = 0;
	private double payMin = 0;
	private double payRebateAmt = 0;
	private double payRebateMin = 0;
	private String payDesc = "";
	private long payId = 0;
	private Date prodDate;
	private String cancelDate = "";
	private String cancelTime = "";
	private int cancelUserId = 0;
	private String cancelReason = "";
	private String cancelRefNo = "";
	private String saleChannel = "";
	private String salesSubChannel = "";
	public ClientInvoice() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ClientInvoice(int clientId, int prodId, int compId, String invNo, double payAmt, double payVat, String payDate,
			String payRef, String payNext, String status, String statusDate, String statusTime, int batchId, double payMin,
			double payRebateAmt, double payRebateMin, String payDesc, long payId, Date prodDate, String cancelDate,
			String cancelTime, int cancelUserId, String cancelReason, String cancelRefNo, String saleChannel,
			String salesSubChannel) {
		super();
		this.clientId = clientId;
		this.prodId = prodId;
		this.compId = compId;
		this.invNo = invNo;
		this.payAmt = payAmt;
		this.payVat = payVat;
		this.payDate = payDate;
		this.payRef = payRef;
		this.payNext = payNext;
		this.status = status;
		this.statusDate = statusDate;
		this.statusTime = statusTime;
		this.batchId = batchId;
		this.payMin = payMin;
		this.payRebateAmt = payRebateAmt;
		this.payRebateMin = payRebateMin;
		this.payDesc = payDesc;
		this.payId = payId;
		this.prodDate = prodDate;
		this.cancelDate = cancelDate;
		this.cancelTime = cancelTime;
		this.cancelUserId = cancelUserId;
		this.cancelReason = cancelReason;
		this.cancelRefNo = cancelRefNo;
		this.saleChannel = saleChannel;
		this.salesSubChannel = salesSubChannel;
	}
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public String getInvNo() {
		return invNo;
	}
	public void setInvNo(String invNo) {
		this.invNo = invNo;
	}
	public double getPayAmt() {
		return payAmt;
	}
	public void setPayAmt(double payAmt) {
		this.payAmt = payAmt;
	}
	public double getPayVat() {
		return payVat;
	}
	public void setPayVat(double payVat) {
		this.payVat = payVat;
	}
	public String getPayDate() {
		return payDate;
	}
	public void setPayDate(String payDate) {
		this.payDate = payDate;
	}
	public String getPayRef() {
		return payRef;
	}
	public void setPayRef(String payRef) {
		this.payRef = payRef;
	}
	public String getPayNext() {
		return payNext;
	}
	public void setPayNext(String payNext) {
		this.payNext = payNext;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusDate() {
		return statusDate;
	}
	public void setStatusDate(String statusDate) {
		this.statusDate = statusDate;
	}
	public String getStatusTime() {
		return statusTime;
	}
	public void setStatusTime(String statusTime) {
		this.statusTime = statusTime;
	}
	public int getBatchId() {
		return batchId;
	}
	public void setBatchId(int batchId) {
		this.batchId = batchId;
	}
	public double getPayMin() {
		return payMin;
	}
	public void setPayMin(double payMin) {
		this.payMin = payMin;
	}
	public double getPayRebateAmt() {
		return payRebateAmt;
	}
	public void setPayRebateAmt(double payRebateAmt) {
		this.payRebateAmt = payRebateAmt;
	}
	public double getPayRebateMin() {
		return payRebateMin;
	}
	public void setPayRebateMin(double payRebateMin) {
		this.payRebateMin = payRebateMin;
	}
	public String getPayDesc() {
		return payDesc;
	}
	public void setPayDesc(String payDesc) {
		this.payDesc = payDesc;
	}
	public long getPayId() {
		return payId;
	}
	public void setPayId(long payId) {
		this.payId = payId;
	}
	public Date getProdDate() {
		return prodDate;
	}
	public void setProdDate(Date prodDate) {
		this.prodDate = prodDate;
	}
	public String getCancelDate() {
		return cancelDate;
	}
	public void setCancelDate(String cancelDate) {
		this.cancelDate = cancelDate;
	}
	public String getCancelTime() {
		return cancelTime;
	}
	public void setCancelTime(String cancelTime) {
		this.cancelTime = cancelTime;
	}
	public int getCancelUserId() {
		return cancelUserId;
	}
	public void setCancelUserId(int cancelUserId) {
		this.cancelUserId = cancelUserId;
	}
	public String getCancelReason() {
		return cancelReason;
	}
	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}
	public String getCancelRefNo() {
		return cancelRefNo;
	}
	public void setCancelRefNo(String cancelRefNo) {
		this.cancelRefNo = cancelRefNo;
	}
	public String getSaleChannel() {
		return saleChannel;
	}
	public void setSaleChannel(String saleChannel) {
		this.saleChannel = saleChannel;
	}
	public String getSalesSubChannel() {
		return salesSubChannel;
	}
	public void setSalesSubChannel(String salesSubChannel) {
		this.salesSubChannel = salesSubChannel;
	}
	@Override
	public String toString() {
		return "ClientInvoice [clientId=" + clientId + ", prodId=" + prodId + ", compId=" + compId + ", invNo=" + invNo
				+ ", payAmt=" + payAmt + ", payVat=" + payVat + ", payDate=" + payDate + ", payRef=" + payRef + ", payNext="
				+ payNext + ", status=" + status + ", statusDate=" + statusDate + ", statusTime=" + statusTime + ", batchId="
				+ batchId + ", payMin=" + payMin + ", payRebateAmt=" + payRebateAmt + ", payRebateMin=" + payRebateMin
				+ ", payDesc=" + payDesc + ", payId=" + payId + ", prodDate=" + prodDate + ", cancelDate=" + cancelDate
				+ ", cancelTime=" + cancelTime + ", cancelUserId=" + cancelUserId + ", cancelReason=" + cancelReason
				+ ", cancelRefNo=" + cancelRefNo + ", saleChannel=" + saleChannel + ", salesSubChannel=" + salesSubChannel
				+ "]";
	}
	
	
	
}
