package za.co.payguru.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import za.co.payguru.model.ClientPayment;

public class ClientPaymentDao {

	public static ArrayList<String> getCompBankClientPayRefs(Connection connection, int compid, int bankid, String startDate, String endDate){
		ArrayList<String> clientPayments = new ArrayList<String>();
		try(
				PreparedStatement statement = connection.prepareStatement("SELECT payref FROM CLIENTPAYMENTS WHERE payid IN (SELECT banktranpayno FROM COMPANYBANKTRANS WHERE bankcompid = ? AND bankid = ? AND banktrandate >= ? AND banktrandate <= ?)");
		){
			statement.setInt(1, compid);
			statement.setInt(2, bankid);
			statement.setString(3, startDate);
			statement.setString(4, endDate);
			ResultSet rs = statement.executeQuery();
			while(rs.next()) {
				String payref = rs.getString("payref");
				clientPayments.add(payref);
			}rs.close();
		}catch (Exception e) {
			System.out.println("Error querying CLIENTPAYMENTS: " + e.toString());
		}
		return clientPayments;
	}
	
	public static ArrayList<ClientPayment> getCompClientPaymentsLast5Days(int compId, Connection connection){
		ArrayList<ClientPayment> clientPayments = new ArrayList<ClientPayment>();
		try(
				PreparedStatement statement = connection.prepareStatement("");
		){
			ResultSet rs = statement.executeQuery();
			while(rs.next()) {
				ClientPayment clientPayment = new ClientPayment();
				clientPayment.setPayId(rs.getLong("payid"));
				clientPayment.setClientId(rs.getInt("clientid"));
				clientPayment.setCompId(rs.getInt("compid"));
				clientPayment.setProdId(rs.getInt("prodid"));
				clientPayment.setBankId(rs.getInt("bankid"));
				clientPayment.setCreateDate(rs.getString("createdate"));
				clientPayment.setCreateTime(rs.getString("createtime"));
				clientPayment.setStatus(rs.getInt("status"));
				clientPayment.setStatusDate(rs.getString("statusdate"));
				clientPayment.setStatusTime(rs.getString("statustime"));
				clientPayment.setPayDate(rs.getString("paydate"));
				clientPayment.setPayAmt(rs.getDouble("payamt"));
				clientPayment.setPayRef(rs.getString("payref"));
				clientPayment.setPayTran(rs.getDouble("paytran"));
				clientPayment.setPayTransferStatus(rs.getInt("paytransferstatus"));
				clientPayment.setPayTransferStatusDate(rs.getString("paytransferstatusdate"));
				clientPayment.setPayTransferStatusTime(rs.getString("paytransferstatustime"));
				clientPayment.setPayTransferStatusUserId(rs.getString("paytransferstatususerid"));
				clientPayment.setPayTransferRef(rs.getString("paytransferref"));
				clientPayment.setPayTransferClientId(rs.getDouble("paytransferclientid"));
				clientPayment.setPayTransferPayId(rs.getDouble("paytransferpayid"));
				clientPayments.add(clientPayment);
			}
		}catch (Exception e) {
			System.out.println("Error querying CLIENTPAYMENTS: " + e.toString());
		}
		return clientPayments;
	}
}
