package za.co.payguru.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import za.co.payguru.model.CompanyUser;
import za.co.payguru.util.DBUtil;


public class CompanyUserDao extends TemplateDao{

	public static CompanyUser getCompanyUserEmail(int compId, String userEmail,Connection connection) {
		CompanyUser companyUser = new CompanyUser();
		try(
				PreparedStatement statement = connection.prepareStatement("SELECT * FROM COMPANYUSERS WHERE compid = ? AND useremail = ?");
		){
			statement.setInt(1, compId);
			statement.setString(2, userEmail);
			ResultSet rs = statement.executeQuery();
			if(rs.next()) {
				companyUser.setCompId(rs.getInt("compid"));
				companyUser.setUserId(rs.getInt("userid"));
				companyUser.setUserName(rs.getString("username"));
				companyUser.setUserSurname(rs.getString("userSurname"));
				companyUser.setUserCellNo(rs.getString("usercellno"));
				companyUser.setUserTelNo(rs.getString("usertelno"));
				companyUser.setUserEmail(rs.getString("useremail"));
				companyUser.setUserPassword(rs.getString("userpassword"));
				companyUser.setUserLoginDateTime(rs.getString("userlogindatetime"));
				companyUser.setUserActive(rs.getString("useractive"));
				companyUser.setUserType(rs.getInt("usertype"));
				companyUser.setProfileId(rs.getInt("profileid"));
				companyUser.setUserPermissions(rs.getString("userpermissions"));
			}rs.close();
		}catch(Exception e) {
			System.out.println("Error querying table COMPANYUSERS: " + e.toString());
		}
		return companyUser;
	}
	
	public static CompanyUser loadCompanyUser(int compId, int userId,Connection connection) {
		CompanyUser companyUser = new CompanyUser();
		try(
				PreparedStatement statement = connection.prepareStatement("SELECT * FROM COMPANYUSERS WHERE compid = ? AND userid = ?");
		){
			statement.setInt(1, compId);
			statement.setInt(2, userId);
			ResultSet rs = statement.executeQuery();
			if(rs.next()) {
				companyUser.setCompId(rs.getInt("compid"));
				companyUser.setUserId(rs.getInt("userid"));
				companyUser.setUserName(rs.getString("username"));
				companyUser.setUserSurname(rs.getString("userSurname"));
				companyUser.setUserCellNo(rs.getString("usercellno"));
				companyUser.setUserTelNo(rs.getString("usertelno"));
				companyUser.setUserEmail(rs.getString("useremail"));
				companyUser.setUserPassword(rs.getString("userpassword"));
				companyUser.setUserLoginDateTime(rs.getString("userlogindatetime"));
				companyUser.setUserActive(rs.getString("useractive"));
				companyUser.setUserType(rs.getInt("usertype"));
				companyUser.setProfileId(rs.getInt("profileid"));
				companyUser.setUserPermissions(rs.getString("userpermissions"));
			}rs.close();
		}catch(Exception e) {
			System.out.println("Error querying table COMPANYUSERS: " + e.toString());
		}
		return companyUser;
	}
	
	
	//JSON HELPER METHODS
	public static StringBuilder getJsonCompanyUser(CompanyUser companyUser) {
		StringBuilder sb = new StringBuilder();
		sb.append("{");
		sb.append("\"compid\" : "+companyUser.getCompId()+",\n");
		sb.append("\"userid\" : "+companyUser.getUserId()+",\n");
		sb.append("\"username\" : \""+companyUser.getUserName()+"\",\n");
		sb.append("\"usersurname\" : \""+companyUser.getUserSurname()+"\",\n");
		sb.append("\"usercellno\" : \""+companyUser.getUserCellNo()+"\",\n");
		sb.append("\"usertelno\" : \""+companyUser.getUserTelNo()+"\",\n");
		sb.append("\"useremail\" : \""+companyUser.getUserEmail()+"\",\n");
		sb.append("\"userpassword\" : \""+companyUser.getUserPassword()+"\",\n");
		sb.append("\"userlogindatetime\" : \""+companyUser.getUserLoginDateTime()+"\",\n");
		sb.append("\"useractive\" : \""+companyUser.getUserActive()+"\",\n");
		sb.append("\"usertype\" : "+companyUser.getUserType()+",\n");
		sb.append("\"profileid\" : "+companyUser.getProfileId()+",\n");
		sb.append("\"userpermissions\" : \""+companyUser.getUserPermissions()+"\"\n");
		sb.append("}");
		return sb;
	}
}
