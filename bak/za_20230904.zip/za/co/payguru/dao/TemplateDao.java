package za.co.payguru.dao;


public class TemplateDao {
}
