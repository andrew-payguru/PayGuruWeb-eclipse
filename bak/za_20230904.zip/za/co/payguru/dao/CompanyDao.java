package za.co.payguru.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import za.co.payguru.model.Company;
import za.co.payguru.model.CompanyUser;
import za.co.payguru.util.DBUtil;

public class CompanyDao extends TemplateDao{
	
	public static Company getCompany(int compId,Connection connection) {
		Company company = new Company();
		try(
				PreparedStatement statement = connection.prepareStatement("SELECT * FROM COMPANYS WHERE compid = ?");
		){
			statement.setInt(1, compId);
			ResultSet rs = statement.executeQuery();
			while(rs.next()) {
				company.setCompId(rs.getInt("compid"));
				company.setCompName(rs.getString("compname"));
				company.setCompTelNo(rs.getString("comptelno"));
				company.setCompCellNo(rs.getString("compcellno"));
				company.setCompVatNo(rs.getString("compvatno"));
				company.setCompRegNo(rs.getString("compregno"));
				company.setCompEmail(rs.getString("compemail"));
				company.setCompWebsite(rs.getString("compwebsite"));
				company.setCompPhysAddr1(rs.getString("compphysaddr1"));
				company.setCompPhysAddr2(rs.getString("compphysaddr2"));
				company.setCompPhysAddr3(rs.getString("compphysaddr3"));
				company.setCompPhysTown(rs.getString("compphystown"));
				company.setCompPhysProv(rs.getString("compphysprov"));
				company.setCompPhysPostCode(rs.getString("compphyspostcode"));
				company.setCompPostAddr1(rs.getString("comppostaddr1"));
				company.setCompPostAddr2(rs.getString("comppostaddr2"));
				company.setCompPostAddr3(rs.getString("comppostaddr3"));
				company.setCompPostTown(rs.getString("compposttown"));
				company.setCompPostProv(rs.getString("comppostprov"));
				company.setCompPostCode(rs.getString("comppostcode"));
				company.setCompJoinName(rs.getString("compjoinname"));
				company.setCompContName(rs.getString("compcontname"));
				company.setCompContSurname(rs.getString("compcontsurname"));
				company.setCompContEmail(rs.getString("compcontemail"));
				company.setCompContCellNo(rs.getString("compcontcellno"));
				company.setCompContTelNo(rs.getString("compconttelno"));
				company.setCompDefProdId(rs.getInt("compdefprodid"));
				company.setCompSysUserId(rs.getString("compsysuserid"));
				company.setCompSysPassword(rs.getString("compsyspassword"));
				company.setCompActive(rs.getString("compactive"));
				company.setCompRef(rs.getString("compref"));
				company.setCompSmsSendRef(rs.getString("compsmssendref"));
				company.setCompSmsMessage1(rs.getString("compsmsmessage1"));
				company.setCompInvPrefix(rs.getString("compinvprefix"));
				company.setCompTaxPerc(rs.getDouble("comptaxperc"));
				company.setCompPayInterfaceId(rs.getString("comppayinterfaceid"));
				company.setCompBankEntity(rs.getString("compbankentity"));
				company.setCompShortenUrl(rs.getString("compshortenurl"));
				company.setCompShortenDir(rs.getString("compshortendir"));
			}rs.close();
		}catch(Exception e) {
			System.out.println("Error querying COMPANY: " + e.toString());
		}
		return company;
	}
	
	
	
	
	
	
	
	
//JSON HELPER METHODS
	public static StringBuilder getJsonCompany(Company company) {
		StringBuilder sb = new StringBuilder();
		sb.append("{\n");
		sb.append("\"compid\" : "+company.getCompId()+",\n");
		sb.append("\"compname\" : \""+company.getCompName()+"\",\n");
		sb.append("\"comptelno\" : \""+company.getCompTelNo()+"\",\n");
		sb.append("\"compcellno\" : \""+company.getCompCellNo()+"\",\n");
		sb.append("\"compvatno\" : \""+company.getCompVatNo()+"\",\n");
		sb.append("\"compregno\" : \""+company.getCompRegNo()+"\",\n");
		sb.append("\"compemail\" : \""+company.getCompEmail()+"\",\n");
		sb.append("\"compwebsite\" : \""+company.getCompWebsite()+"\",\n");
		sb.append("\"compphysaddr1\" : \""+company.getCompPhysAddr1()+"\",\n");
		sb.append("\"compphysaddr2\" : \""+company.getCompPhysAddr2()+"\",\n");
		sb.append("\"compphysaddr3\" : \""+company.getCompPhysAddr3()+"\",\n");
		sb.append("\"compphystown\" : \""+company.getCompPhysTown()+"\",\n");
		sb.append("\"compphysprov\" : \""+company.getCompPhysProv()+"\",\n");
		sb.append("\"compphyspostcode\" : \""+company.getCompPhysPostCode()+"\",\n");
		sb.append("\"comppostaddr1\" : \""+company.getCompPostAddr1()+"\",\n");
		sb.append("\"comppostaddr2\" : \""+company.getCompPostAddr2()+"\",\n");
		sb.append("\"comppostaddr3\" : \""+company.getCompPostAddr3()+"\",\n");
		sb.append("\"compposttown\" : \""+company.getCompPostTown()+"\",\n");
		sb.append("\"comppostprov\" : \""+company.getCompPostProv()+"\",\n");
		sb.append("\"comppostcode\" : \""+company.getCompPostCode()+"\",\n");
		sb.append("\"compjoinname\" : \""+company.getCompJoinName()+"\",\n");
		sb.append("\"compcontname\" : \""+company.getCompContName()+"\",\n");
		sb.append("\"compcontsurname\" : \""+company.getCompContSurname()+"\",\n");
		sb.append("\"compcontemail\" : \""+company.getCompContEmail()+"\",\n");
		sb.append("\"compcontcellno\" : \""+company.getCompContCellNo()+"\",\n");
		sb.append("\"compconttelno\" : \""+company.getCompContTelNo()+"\",\n");
		sb.append("\"compdefprodid\" : "+company.getCompDefProdId()+",\n");
		sb.append("\"compsysuserid\" : \""+company.getCompSysUserId()+"\",\n");
		sb.append("\"compsyspassword\" : \""+company.getCompSysPassword()+"\",\n");
		sb.append("\"compactive\" : \""+company.getCompActive()+"\",\n");
		sb.append("\"compref\" : \""+company.getCompRef()+"\",\n");
		sb.append("\"compsmssendref\" : \""+company.getCompSmsSendRef()+"\",\n");
		sb.append("\"compsmsmessage1\" : \""+company.getCompSmsMessage1()+"\",\n");
		sb.append("\"compinvprefix\" : \""+company.getCompInvPrefix()+"\",\n");
		sb.append("\"comptaxperc\" : "+company.getCompTaxPerc()+",\n");
		sb.append("\"comppayinterfaceid\" : \""+company.getCompPayInterfaceId()+"\",\n");
		sb.append("\"compbankentity\" : \""+company.getCompBankEntity()+"\",\n");
		sb.append("\"compshortenurl\" : \""+company.getCompShortenUrl()+"\",\n");
		sb.append("\"compshortendir\" : \""+company.getCompShortenDir()+"\"\n");
		sb.append("}");
		return sb;
	}
}
