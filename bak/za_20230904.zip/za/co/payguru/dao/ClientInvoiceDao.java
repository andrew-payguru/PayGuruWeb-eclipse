package za.co.payguru.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import za.co.payguru.model.ClientInvoice;
import za.co.payguru.model.CompanyProduct;
import za.co.payguru.util.DateUtil;
import za.co.payguru.util.JSONHelper;
import za.co.payguru.util.Util;

public class ClientInvoiceDao {

	//paydate not startdate
	public static ArrayList<ClientInvoice> getChannelClientInvoiceSales(Connection connection, int compId, int compinternalid, int prodid, String channel, String startDate, String endDate){
		ArrayList<ClientInvoice> clientInvoices = new ArrayList<ClientInvoice>();
		
		try(
				PreparedStatement statement = connection.prepareStatement("SELECT * FROM CLIENTINVOICES WHERE compid = ? AND paydate >= ? AND paydate <= ? " + (channel.equalsIgnoreCase("ALL") ? "" : "AND salechannel = '"+channel.toUpperCase()+"'") + " AND (status = ? OR status = ?) AND prodid IN (SELECT prodid FROM COMPANYPRODUCTS WHERE compid = ?" + (prodid>0 ? " AND prodid = " + prodid : "") + (compinternalid>0 ? (" AND compinternalid = "+ compinternalid) : "") + ") ORDER BY paydate, invno");
		){
			statement.setInt(1, compId);
			statement.setString(2, startDate.replace('-', '/'));
			statement.setString(3, endDate.replace('-', '/'));
			statement.setString(4, ClientInvoice.INVOICE_PAID);
			statement.setString(5, ClientInvoice.INVOICE_ACTIVE);
			statement.setInt(6, compId);
			System.out.println("\n\nSQL2: " + statement.toString());
			ResultSet rs = statement.executeQuery();
			while(rs.next()) {
				ClientInvoice clientInvoice = new ClientInvoice();
				clientInvoice.setClientId(rs.getInt("clientid"));
				clientInvoice.setProdId(rs.getInt("prodid"));
				clientInvoice.setCompId(rs.getInt("compid"));
				clientInvoice.setInvNo(rs.getString("invno"));
				clientInvoice.setPayAmt(rs.getDouble("payamt"));
				clientInvoice.setPayVat(rs.getDouble("payvat"));
				clientInvoice.setPayDate(rs.getString("paydate"));
				clientInvoice.setPayRef(rs.getString("payref"));
				clientInvoice.setPayNext(rs.getString("paynext"));
				clientInvoice.setStatus(rs.getString("status"));
				clientInvoice.setStatusDate(rs.getString("statusdate"));
				clientInvoice.setStatusTime(rs.getString("statustime"));
				clientInvoice.setBatchId(rs.getInt("batchid"));
				clientInvoice.setPayMin(rs.getDouble("paymin"));
				clientInvoice.setPayRebateAmt(rs.getDouble("payrebateamt"));
				clientInvoice.setPayRebateMin(rs.getDouble("payrebatemin"));
				clientInvoice.setPayDesc(rs.getString("paydesc"));
				clientInvoice.setPayId(rs.getLong("payid"));
				clientInvoice.setProdDate(rs.getDate("proddate"));
				clientInvoice.setCancelDate(rs.getString("canceldate"));
				clientInvoice.setCancelTime(rs.getString("canceltime"));
				clientInvoice.setCancelUserId(rs.getInt("canceluserid"));
				clientInvoice.setCancelReason(rs.getString("cancelreason"));
				clientInvoice.setCancelRefNo(rs.getString("cancelrefno"));
				clientInvoice.setSaleChannel(rs.getString("salechannel"));
				clientInvoice.setSalesSubChannel(rs.getString("salesubchannel"));
				clientInvoices.add(clientInvoice);
			}rs.close();
		}catch (Exception e) {
			System.out.println();
		}
		return clientInvoices;
	}
	
	public static ArrayList<ClientInvoice> getChannelClientInvoices(Connection connection, int compId, int compinternalid, int prodid, String channel, String startDate, String endDate){
		ArrayList<ClientInvoice> clientInvoices = new ArrayList<ClientInvoice>();
		
		try(
				PreparedStatement statement = connection.prepareStatement("SELECT * FROM CLIENTINVOICES WHERE compid = ? AND paydate >= ? AND paydate <= ? " + (channel.equalsIgnoreCase("ALL") ? "" : "AND salechannel = '"+channel.toUpperCase()+"'") + " AND (status = ? OR status = ?) AND invno IN (SELECT invno FROM CLIENTINVOICEDATA WHERE compid = ? AND invdataref8 >= ? AND invdataref8 <= ?)  AND prodid IN (SELECT prodid FROM COMPANYPRODUCTS WHERE compid = ?" + (prodid>0 ? " AND prodid = " + prodid : "") + (compinternalid>0 ? (" AND compinternalid = "+ compinternalid) : "") + ") ORDER BY paydate, invno");
		){
			statement.setInt(1, compId);
			statement.setString(2, String.valueOf(DateUtil.getPrevDate(DateUtil.getDateValue(startDate))).replace('-', '/'));
			statement.setString(3, endDate.replace('-', '/'));
			statement.setString(4, ClientInvoice.INVOICE_PAID);
			statement.setString(5, ClientInvoice.INVOICE_ACTIVE);
			statement.setInt(6, compId);
			statement.setString(7, startDate.replace('-', '/'));
			statement.setString(8, endDate.replace('-', '/'));
			statement.setInt(9, compId);
			ResultSet rs = statement.executeQuery();
			while(rs.next()) {
				ClientInvoice clientInvoice = new ClientInvoice();
				clientInvoice.setClientId(rs.getInt("clientid"));
				clientInvoice.setProdId(rs.getInt("prodid"));
				clientInvoice.setCompId(rs.getInt("compid"));
				clientInvoice.setInvNo(rs.getString("invno"));
				clientInvoice.setPayAmt(rs.getDouble("payamt"));
				clientInvoice.setPayVat(rs.getDouble("payvat"));
				clientInvoice.setPayDate(rs.getString("paydate"));
				clientInvoice.setPayRef(rs.getString("payref"));
				clientInvoice.setPayNext(rs.getString("paynext"));
				clientInvoice.setStatus(rs.getString("status"));
				clientInvoice.setStatusDate(rs.getString("statusdate"));
				clientInvoice.setStatusTime(rs.getString("statustime"));
				clientInvoice.setBatchId(rs.getInt("batchid"));
				clientInvoice.setPayMin(rs.getDouble("paymin"));
				clientInvoice.setPayRebateAmt(rs.getDouble("payrebateamt"));
				clientInvoice.setPayRebateMin(rs.getDouble("payrebatemin"));
				clientInvoice.setPayDesc(rs.getString("paydesc"));
				clientInvoice.setPayId(rs.getLong("payid"));
				clientInvoice.setProdDate(rs.getDate("proddate"));
				clientInvoice.setCancelDate(rs.getString("canceldate"));
				clientInvoice.setCancelTime(rs.getString("canceltime"));
				clientInvoice.setCancelUserId(rs.getInt("canceluserid"));
				clientInvoice.setCancelReason(rs.getString("cancelreason"));
				clientInvoice.setCancelRefNo(rs.getString("cancelrefno"));
				clientInvoice.setSaleChannel(rs.getString("salechannel"));
				clientInvoice.setSalesSubChannel(rs.getString("salesubchannel"));
				clientInvoices.add(clientInvoice);
			}rs.close();
		}catch (Exception e) {
			System.out.println();
		}
		return clientInvoices;
	}
	
	public static ArrayList<String> getCompClientInvoicesGraph(int compId, int prevDays, Connection connection) {
		ArrayList<String> data = new ArrayList<String>();
		try(
				PreparedStatement statement = connection.prepareStatement("SELECT prodid,paydate,count(*) FROM CLIENTINVOICES WHERE compid = ? AND paydate >= ? AND paydate <= ? GROUP BY prodid,paydate ORDER BY prodid,paydate");
		){
			Date today = DateUtil.getCurrentCCYYMMDDDate();
			statement.setInt(1, compId);
			statement.setString(2, String.valueOf(DateUtil.getPrevDate(today, prevDays, true)).replace("-", "/"));
			statement.setString(3, String.valueOf(today).replace("-", "/"));
			ResultSet rs = statement.executeQuery();
			while(rs.next()) {
				String paydate = rs.getString("paydate");
				int prodid = rs.getInt("prodid");
				CompanyProduct prod = CompanyProductDao.getCompanyProducts(compId, prodid, connection);
				if(prod.getProdId()<=0)
					continue;
				String prodname = prod.getProdName();
				int count = rs.getInt("count");
				data.add(paydate+"|"+prodid+"|"+prodname+"|"+count);
			}
		}catch (Exception e) {
			System.out.println("Error querying CLIENTINVOICES: " + e.toString());
		}
		return data;
	}
	
	
	public static StringBuffer getCompClientInvoiceGraphJSON(ArrayList<String> data) {
		StringBuffer sb = new StringBuffer();
		StringBuffer labels = new StringBuffer();
		String currDate = "";
		String currProdId = "";
		HashMap<String, String> prodDataMap = new HashMap<String, String>();
		HashMap<String, HashMap<String, String>> dataMap = new HashMap<String, HashMap<String, String>>();
		for(int i=0;i<data.size();i++) {
			String entry = data.get(i);
			String paydate = Util.getValueAt(entry, "|", 0);
			String prodid = Util.getValueAt(entry, "|", 1);
			String prodname = Util.getValueAt(entry, "|", 2);
			String count = Util.getValueAt(entry, "|", 3);
			if(currDate.equals(paydate)==false) {
				dataMap.put(currDate, prodDataMap);
				currDate = paydate;
				prodDataMap.clear();
			}
			prodDataMap.put(prodid, count);
		}
		return sb;
	}

	//JSON HELPER METHODS
	public static StringBuilder getClientInvoicesJSON(ArrayList<ClientInvoice> clientInvoices) {
		StringBuilder sb = new StringBuilder();
		sb.append("[\n");
		for(int i=0;i<clientInvoices.size();i++) {
			ClientInvoice invoice = clientInvoices.get(i);
			sb.append("{\n");
			sb.append("\"invno\" : \""+invoice.getInvNo()+"\",\n");
			sb.append("\"clientid\" : "+invoice.getClientId()+",\n");
			sb.append("\"compid\" : "+invoice.getCompId()+",\n");
			sb.append("\"prodid\" : "+invoice.getProdId()+",\n");
			sb.append("\"payamt\" : "+invoice.getPayAmt()+",\n");
			sb.append("\"payvat\" : "+invoice.getPayVat()+",\n");
			sb.append("\"paydate\" : \""+invoice.getPayDate()+"\",\n");
			sb.append("\"payref\" : \""+JSONHelper.fixJSONString(invoice.getPayRef())+"\",\n");
			sb.append("\"paynext\" : "+invoice.getPayNext()+",\n");
			sb.append("\"status\" : \""+invoice.getStatus()+"\",\n");
			sb.append("\"statusdate\" : \""+invoice.getStatusDate()+"\",\n");
			sb.append("\"statustime\" : \""+invoice.getStatusTime()+"\",\n");
			sb.append("\"batchid\" : "+invoice.getBatchId()+",\n");
			sb.append("\"paymin\" : "+invoice.getPayMin()+",\n");
			sb.append("\"payrebateamt\" : "+invoice.getPayRebateAmt()+",\n");
			sb.append("\"payrebatemin\" : "+invoice.getPayRebateMin()+",\n");
			sb.append("\"paydesc\" : \""+JSONHelper.fixJSONString(invoice.getPayDesc())+"\",\n");
			sb.append("\"payid\" : "+invoice.getPayId()+",\n");
			sb.append("\"proddate\" : \""+invoice.getProdDate()+"\",\n");
			sb.append("\"canceldate\" : \""+invoice.getCancelDate()+"\",\n");
			sb.append("\"canceltime\" : \""+invoice.getCancelTime()+"\",\n");
			sb.append("\"canceluserid\" : "+invoice.getCancelUserId()+",\n");
			sb.append("\"cancelreason\" : \""+JSONHelper.fixJSONString(invoice.getCancelReason())+"\",\n");
			sb.append("\"cancelrefno\" : \""+JSONHelper.fixJSONString(invoice.getCancelRefNo())+"\",\n");
			sb.append("\"salechannel\" : \""+invoice.getSaleChannel()+"\",\n");
			sb.append("\"salesubchannel\" : \""+invoice.getSalesSubChannel()+"\"\n");
			sb.append("}" + (i==clientInvoices.size()-1 ? "" : ",") + "\n");
		}
		sb.append("]");
		return sb;
	}
	
	
}
