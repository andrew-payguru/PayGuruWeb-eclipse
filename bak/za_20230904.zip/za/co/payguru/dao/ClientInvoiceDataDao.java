package za.co.payguru.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import za.co.payguru.model.ClientInvoice;
import za.co.payguru.model.ClientInvoiceData;
import za.co.payguru.util.DateUtil;
import za.co.payguru.util.JSONHelper;

public class ClientInvoiceDataDao {

	//paydate not startdate
	public static ArrayList<ClientInvoiceData> getChannelClientInvoiceDataSales(Connection connection, int compId, int compinternalid, int prodid, String channel, String startDate, String endDate){
		ArrayList<ClientInvoiceData> clientInvoiceDatas = new ArrayList<ClientInvoiceData>();
		try(
				PreparedStatement statement = connection.prepareStatement("SELECT * FROM CLIENTINVOICEDATA WHERE invno IN (SELECT invno FROM CLIENTINVOICES WHERE compid = ? AND paydate >= ? AND paydate <= ? " + (channel.equalsIgnoreCase("ALL") ? "" : "AND salechannel = '"+channel.toUpperCase()+"'") + " AND (status = ? OR status = ?) AND prodid IN (SELECT prodid FROM COMPANYPRODUCTS WHERE compid = ?" + (prodid>0 ? " AND prodid = " + prodid : "") + (compinternalid>0 ? (" AND compinternalid = "+ compinternalid) : "") + ") ORDER BY paydate, invno)");
		){
			statement.setInt(1, compId);
			statement.setString(2, startDate.replace('-', '/'));
			statement.setString(3, endDate.replace('-', '/'));
			statement.setString(4, ClientInvoice.INVOICE_PAID);
			statement.setString(5, ClientInvoice.INVOICE_ACTIVE);
			statement.setInt(6, compId);
			System.out.println("\n\nSQL1: " + statement.toString());
			ResultSet rs = statement.executeQuery();
			while(rs.next()) {
				ClientInvoiceData clientInvoiceData = new ClientInvoiceData();
				clientInvoiceData.setInvNo(rs.getString("invno"));
				clientInvoiceData.setCompId(rs.getInt("compid"));
				clientInvoiceData.setInvData(rs.getString("invdata").trim().replace('\n', ' ').replace("\r\n", " ").replace("\t", "").replace("\\", ""));
				clientInvoiceData.setInvDataType(rs.getString("invdatatype").trim().replace('\n', ' ').replace("\r\n", " ").replace("\t", "").replace("\\", ""));
				clientInvoiceData.setInvDataRef1(rs.getString("invdataref1").trim().replace('\n', ' ').replace("\r\n", " ").replace("\t", "").replace("\\", ""));
				clientInvoiceData.setInvDataRef2(rs.getString("invdataref2").trim().replace('\n', ' ').replace("\r\n", " ").replace("\t", "").replace("\\", ""));
				clientInvoiceData.setInvDataRef3(rs.getString("invdataref3").trim().replace('\n', ' ').replace("\r\n", " ").replace("\t", "").replace("\\", ""));
				clientInvoiceData.setInvDataRef4(rs.getString("invdataref4").trim().replace('\n', ' ').replace("\r\n", " ").replace("\t", "").replace("\\", ""));
				clientInvoiceData.setInvDataRef5(rs.getString("invdataref5").trim().replace('\n', ' ').replace("\r\n", " ").replace("\t", "").replace("\\", ""));
				clientInvoiceData.setInvDataRef6(rs.getString("invdataref6").trim().replace('\n', ' ').replace("\r\n", " ").replace("\t", "").replace("\\", ""));
				clientInvoiceData.setInvDataRef7(rs.getString("invdataref7").trim().replace('\n', ' ').replace("\r\n", " ").replace("\t", "").replace("\\", ""));
				clientInvoiceData.setInvDataRef8(rs.getString("invdataref8").trim().replace('\n', ' ').replace("\r\n", " ").replace("\t", "").replace("\\", ""));
				clientInvoiceData.setInvDataAmt1(rs.getDouble("invdataamt1"));
				clientInvoiceData.setInvDataAmt2(rs.getDouble("invdataamt2"));
				clientInvoiceData.setInvDataAmt3(rs.getDouble("invdataamt3"));
				clientInvoiceData.setInvDataAmt4(rs.getDouble("invdataamt4"));
				clientInvoiceData.setInvDataAmt5(rs.getDouble("invdataamt5"));
				clientInvoiceData.setInvLink(rs.getString("invlink"));
				clientInvoiceData.setClientId(rs.getInt("clientid"));
				clientInvoiceDatas.add(clientInvoiceData);
			}rs.close();
		}catch (Exception e) {
			System.out.println("Error querying table: " + e.toString());
		}
		return clientInvoiceDatas;
	}
	
	
	public static ArrayList<ClientInvoiceData> getChannelClientInvoiceData(Connection connection, int compId, int compinternalid, int prodid, String channel, String startDate, String endDate){
		ArrayList<ClientInvoiceData> clientInvoiceDatas = new ArrayList<ClientInvoiceData>();
		try(
				PreparedStatement statement = connection.prepareStatement("SELECT * FROM CLIENTINVOICEDATA WHERE invno IN (SELECT invno FROM CLIENTINVOICES WHERE compid = ? AND paydate >= ? AND paydate <= ? " + (channel.equalsIgnoreCase("ALL") ? "" : "AND salechannel = '"+channel.toUpperCase()+"'") + " AND (status = ? OR status = ?) AND prodid IN (SELECT prodid FROM COMPANYPRODUCTS WHERE compid = ?" + (prodid>0 ? " AND prodid = " + prodid : "") + (compinternalid>0 ? (" AND compinternalid = "+ compinternalid) : "") + ") AND invdataref8 >= ? AND invdataref8 <= ? ORDER BY paydate, invno)");
		){
			statement.setInt(1, compId);
			statement.setString(2, String.valueOf(DateUtil.getPrevDate(DateUtil.getDateValue(startDate))).replace('-', '/'));
			statement.setString(3, endDate.replace('-', '/'));
			statement.setString(4, ClientInvoice.INVOICE_PAID);
			statement.setString(5, ClientInvoice.INVOICE_ACTIVE);
			statement.setInt(6, compId);
			statement.setString(7, startDate.replace('-', '/'));
			statement.setString(8, endDate.replace('-', '/'));
			ResultSet rs = statement.executeQuery();
			while(rs.next()) {
				ClientInvoiceData clientInvoiceData = new ClientInvoiceData();
				clientInvoiceData.setInvNo(rs.getString("invno"));
				clientInvoiceData.setCompId(rs.getInt("compid"));
				clientInvoiceData.setInvData(rs.getString("invdata"));
				clientInvoiceData.setInvDataType(rs.getString("invdatatype"));
				clientInvoiceData.setInvDataRef1(rs.getString("invdataref1"));
				clientInvoiceData.setInvDataRef2(rs.getString("invdataref2"));
				clientInvoiceData.setInvDataRef3(rs.getString("invdataref3"));
				clientInvoiceData.setInvDataRef4(rs.getString("invdataref4"));
				clientInvoiceData.setInvDataRef5(rs.getString("invdataref5"));
				clientInvoiceData.setInvDataRef6(rs.getString("invdataref6"));
				clientInvoiceData.setInvDataRef7(rs.getString("invdataref7"));
				clientInvoiceData.setInvDataRef8(rs.getString("invdataref8"));
				clientInvoiceData.setInvDataAmt1(rs.getDouble("invdataamt1"));
				clientInvoiceData.setInvDataAmt2(rs.getDouble("invdataamt2"));
				clientInvoiceData.setInvDataAmt3(rs.getDouble("invdataamt3"));
				clientInvoiceData.setInvDataAmt4(rs.getDouble("invdataamt4"));
				clientInvoiceData.setInvDataAmt5(rs.getDouble("invdataamt5"));
				clientInvoiceData.setInvLink(rs.getString("invlink"));
				clientInvoiceData.setClientId(rs.getInt("clientid"));
				clientInvoiceDatas.add(clientInvoiceData);
			}rs.close();
		}catch (Exception e) {
			System.out.println("Error querying table: " + e.toString());
		}
		return clientInvoiceDatas;
	}
	
	
	//JSON HELPERS
	public static StringBuilder getClientInvoiceDatasJSON(ArrayList<ClientInvoiceData> invData) {
		StringBuilder sb = new StringBuilder();
		sb.append("[\n");
		for(int i=0;i<invData.size();i++) {
			ClientInvoiceData data = invData.get(i);
			sb.append("{\n");
			sb.append("\"invno\" : \""+data.getInvNo()+"\",\n");
			sb.append("\"compid\" : "+data.getCompId()+",\n");
			sb.append("\"invdata\" : \""+JSONHelper.fixJSONString(data.getInvData())+"\",\n");
			sb.append("\"invdatatype\" : \""+JSONHelper.fixJSONString(data.getInvDataType())+"\",\n");
			sb.append("\"invdataref1\" : \""+JSONHelper.fixJSONString(data.getInvDataRef1())+"\",\n");
			sb.append("\"invdataref2\" : \""+JSONHelper.fixJSONString(data.getInvDataRef2())+"\",\n");
			sb.append("\"invdataref3\" : \""+JSONHelper.fixJSONString(data.getInvDataRef3())+"\",\n");
			sb.append("\"invdataref4\" : \""+JSONHelper.fixJSONString(data.getInvDataRef4())+"\",\n");
			sb.append("\"invdataref5\" : \""+JSONHelper.fixJSONString(data.getInvDataRef5())+"\",\n");
			sb.append("\"invdataref6\" : \""+JSONHelper.fixJSONString(data.getInvDataRef6())+"\",\n");
			sb.append("\"invdataref7\" : \""+JSONHelper.fixJSONString(data.getInvDataRef7())+"\",\n");
			sb.append("\"invdataref8\" : \""+JSONHelper.fixJSONString(data.getInvDataRef8())+"\",\n");
			sb.append("\"invdataamt1\" : "+data.getInvDataAmt1()+",\n");
			sb.append("\"invdataamt2\" : "+data.getInvDataAmt2()+",\n");
			sb.append("\"invdataamt3\" : "+data.getInvDataAmt3()+",\n");
			sb.append("\"invdataamt4\" : "+data.getInvDataAmt4()+",\n");
			sb.append("\"invdataamt5\" : "+data.getInvDataAmt5()+",\n");
			sb.append("\"invlink\" : \""+JSONHelper.fixJSONString(data.getInvLink())+"\",\n");
			sb.append("\"clientid\" : "+data.getClientId()+"\n");
			sb.append("}" + (i==invData.size()-1 ? "" : ",") + "\n");
		}
		sb.append("]");
		return sb;
	}
}
