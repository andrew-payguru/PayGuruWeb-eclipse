package za.co.payguru.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import za.co.payguru.model.Param;
import za.co.payguru.util.DBUtil;

public class ParamDao extends TemplateDao{
	public static Param getParam(String paramID, Connection connection){
		Param param = new Param();
		try(
				PreparedStatement statement = connection.prepareStatement("SELECT * FROM PARAMS WHERE paramid = ?");
		){
			statement.setString(1, paramID);
			ResultSet rs = statement.executeQuery();
			if(rs.next()) {
				param.setParamID(rs.getString("paramid"));
				param.setParamValue(rs.getString("paramvalue"));
			}
			rs.close();
		}catch(Exception e) {
			System.out.println("Error querying PARAMS table: " + e.toString());
		}
		return param;
	}
}
