package za.co.payguru.model;

public class Client {
	private int clientId = 0;
	private String clientName = "";
	private String clientSurname = "";
	private String clientIdNo = "";
	private String clientTelNo = "";
	private String clientCellNo = "";
	private String clientVatNo = "";
	private String clientRegNo = "";
	private String clientEmail = "";
	private String clientWebsite = "";
	private String clientPhysAddr1 = "";
	private String clientPhysAddr2 = "";
	private String clientPhysAddr3 = "";
	private String clientPhysTown = "";
	private String clientPhysProv = "";
	private String clientPhysPostCode = "";
	private String clientPostAddr1 = "";
	private String clientPostAddr2 = "";
	private String clientPostAddr3 = "";
	private String clientPostTown = "";
	private String clientPostProv = "";
	private String clientPostCode = "";
	private String contName = "";
	private String contSurname = "";
	private String contEmail = "";
	private String contCellNo = "";
	private String contTelNo = "";
	private String clientPayRef = "";
	private String clientDeviceNo = "";
	private String clientInitDate = "";
	private String clientRef = "";
	private String clientPassword = "";
	private long clientPasswordMillis = 0;
	private String clientUniqueID = "";
	private long clientUniqueMillis = 0;
	public Client(int clientId, String clientName, String clientSurname, String clientIdNo, String clientTelNo,
			String clientCellNo, String clientVatNo, String clientRegNo, String clientEmail, String clientWebsite,
			String clientPhysAddr1, String clientPhysAddr2, String clientPhysAddr3, String clientPhysTown,
			String clientPhysProv, String clientPhysPostCode, String clientPostAddr1, String clientPostAddr2,
			String clientPostAddr3, String clientPostTown, String clientPostProv, String clientPostCode, String contName,
			String contSurname, String contEmail, String contCellNo, String contTelNo, String clientPayRef,
			String clientDeviceNo, String clientInitDate, String clientRef, String clientPassword,
			long clientPasswordMillis, String clientUniqueID, long clientUniqueMillis ) {
		super();
		this.clientId = clientId;
		this.clientName = clientName;
		this.clientSurname = clientSurname;
		this.clientIdNo = clientIdNo;
		this.clientTelNo = clientTelNo;
		this.clientCellNo = clientCellNo;
		this.clientVatNo = clientVatNo;
		this.clientRegNo = clientRegNo;
		this.clientEmail = clientEmail;
		this.clientWebsite = clientWebsite;
		this.clientPhysAddr1 = clientPhysAddr1;
		this.clientPhysAddr2 = clientPhysAddr2;
		this.clientPhysAddr3 = clientPhysAddr3;
		this.clientPhysTown = clientPhysTown;
		this.clientPhysProv = clientPhysProv;
		this.clientPhysPostCode = clientPhysPostCode;
		this.clientPostAddr1 = clientPostAddr1;
		this.clientPostAddr2 = clientPostAddr2;
		this.clientPostAddr3 = clientPostAddr3;
		this.clientPostTown = clientPostTown;
		this.clientPostProv = clientPostProv;
		this.clientPostCode = clientPostCode;
		this.contName = contName;
		this.contSurname = contSurname;
		this.contEmail = contEmail;
		this.contCellNo = contCellNo;
		this.contTelNo = contTelNo;
		this.clientPayRef = clientPayRef;
		this.clientDeviceNo = clientDeviceNo;
		this.clientInitDate = clientInitDate;
		this.clientRef = clientRef;
		this.clientPassword = clientPassword;
		this.clientPasswordMillis = clientPasswordMillis;
		this.clientUniqueID = clientUniqueID;
		this.clientUniqueMillis = this.clientUniqueMillis;
	}
	public Client() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	public String getClientUniqueID() {
		return clientUniqueID;
	}
	public void setClientUniqueID(String clientUniqueID) {
		this.clientUniqueID = clientUniqueID;
	}
	public long getClientUniqueMillis() {
		return clientUniqueMillis;
	}
	public void setClientUniqueMillis(long clientUniqueMillis) {
		this.clientUniqueMillis = clientUniqueMillis;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getClientSurname() {
		return clientSurname;
	}
	public void setClientSurname(String clientSurname) {
		this.clientSurname = clientSurname;
	}
	public String getClientIdNo() {
		return clientIdNo;
	}
	public void setClientIdNo(String clientIdNo) {
		this.clientIdNo = clientIdNo;
	}
	public String getClientTelNo() {
		return clientTelNo;
	}
	public void setClientTelNo(String clientTelNo) {
		this.clientTelNo = clientTelNo;
	}
	public String getClientCellNo() {
		return clientCellNo;
	}
	public void setClientCellNo(String clientCellNo) {
		this.clientCellNo = clientCellNo;
	}
	public String getClientVatNo() {
		return clientVatNo;
	}
	public void setClientVatNo(String clientVatNo) {
		this.clientVatNo = clientVatNo;
	}
	public String getClientRegNo() {
		return clientRegNo;
	}
	public void setClientRegNo(String clientRegNo) {
		this.clientRegNo = clientRegNo;
	}
	public String getClientEmail() {
		return clientEmail;
	}
	public void setClientEmail(String clientEmail) {
		this.clientEmail = clientEmail;
	}
	public String getClientWebsite() {
		return clientWebsite;
	}
	public void setClientWebsite(String clientWebsite) {
		this.clientWebsite = clientWebsite;
	}
	public String getClientPhysAddr1() {
		return clientPhysAddr1;
	}
	public void setClientPhysAddr1(String clientPhysAddr1) {
		this.clientPhysAddr1 = clientPhysAddr1;
	}
	public String getClientPhysAddr2() {
		return clientPhysAddr2;
	}
	public void setClientPhysAddr2(String clientPhysAddr2) {
		this.clientPhysAddr2 = clientPhysAddr2;
	}
	public String getClientPhysAddr3() {
		return clientPhysAddr3;
	}
	public void setClientPhysAddr3(String clientPhysAddr3) {
		this.clientPhysAddr3 = clientPhysAddr3;
	}
	public String getClientPhysTown() {
		return clientPhysTown;
	}
	public void setClientPhysTown(String clientPhysTown) {
		this.clientPhysTown = clientPhysTown;
	}
	public String getClientPhysProv() {
		return clientPhysProv;
	}
	public void setClientPhysProv(String clientPhysProv) {
		this.clientPhysProv = clientPhysProv;
	}
	public String getClientPhysPostCode() {
		return clientPhysPostCode;
	}
	public void setClientPhysPostCode(String clientPhysPostCode) {
		this.clientPhysPostCode = clientPhysPostCode;
	}
	public String getClientPostAddr1() {
		return clientPostAddr1;
	}
	public void setClientPostAddr1(String clientPostAddr1) {
		this.clientPostAddr1 = clientPostAddr1;
	}
	public String getClientPostAddr2() {
		return clientPostAddr2;
	}
	public void setClientPostAddr2(String clientPostAddr2) {
		this.clientPostAddr2 = clientPostAddr2;
	}
	public String getClientPostAddr3() {
		return clientPostAddr3;
	}
	public void setClientPostAddr3(String clientPostAddr3) {
		this.clientPostAddr3 = clientPostAddr3;
	}
	public String getClientPostTown() {
		return clientPostTown;
	}
	public void setClientPostTown(String clientPostTown) {
		this.clientPostTown = clientPostTown;
	}
	public String getClientPostProv() {
		return clientPostProv;
	}
	public void setClientPostProv(String clientPostProv) {
		this.clientPostProv = clientPostProv;
	}
	public String getClientPostCode() {
		return clientPostCode;
	}
	public void setClientPostCode(String clientPostCode) {
		this.clientPostCode = clientPostCode;
	}
	public String getContName() {
		return contName;
	}
	public void setContName(String contName) {
		this.contName = contName;
	}
	public String getContSurname() {
		return contSurname;
	}
	public void setContSurname(String contSurname) {
		this.contSurname = contSurname;
	}
	public String getContEmail() {
		return contEmail;
	}
	public void setContEmail(String contEmail) {
		this.contEmail = contEmail;
	}
	public String getContCellNo() {
		return contCellNo;
	}
	public void setContCellNo(String contCellNo) {
		this.contCellNo = contCellNo;
	}
	public String getContTelNo() {
		return contTelNo;
	}
	public void setContTelNo(String contTelNo) {
		this.contTelNo = contTelNo;
	}
	public String getClientPayRef() {
		return clientPayRef;
	}
	public void setClientPayRef(String clientPayRef) {
		this.clientPayRef = clientPayRef;
	}
	public String getClientDeviceNo() {
		return clientDeviceNo;
	}
	public void setClientDeviceNo(String clientDeviceNo) {
		this.clientDeviceNo = clientDeviceNo;
	}
	public String getClientInitDate() {
		return clientInitDate;
	}
	public void setClientInitDate(String clientInitDate) {
		this.clientInitDate = clientInitDate;
	}
	public String getClientRef() {
		return clientRef;
	}
	public void setClientRef(String clientRef) {
		this.clientRef = clientRef;
	}
	public String getClientPassword() {
		return clientPassword;
	}
	public void setClientPassword(String clientPassword) {
		this.clientPassword = clientPassword;
	}
	public long getClientPasswordMillis() {
		return clientPasswordMillis;
	}
	public void setClientPasswordMillis(long clientPasswordMillis) {
		this.clientPasswordMillis = clientPasswordMillis;
	}
	
		
}
