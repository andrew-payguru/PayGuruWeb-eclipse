package za.co.payguru.model;

public class CompanyBankTran {
	public static String COMPBANKTRAN_ACTIVE = "1";
	public static String COMPBANKTRAN_INACTIVE = "0";
  public static final String STATUS_INIT           = "I";
	public static final String STATUS_ACTIVE         = "1";
	public static final String STATUS_BUSY           = "2";
	public static final String STATUS_DONE           = "3";
	public static final String STATUS_ERROR          = "4";
	public static final String STATUS_INVALIDREF     = "5";
	public static final String STATUS_INVALIDDETAILS = "6";
	public static final String STATUS_SAMEDAY        = "7";
	
	private long bankTranId;
	private int bankCompId;
	private int bankId;
	private int bankTranType;
	private String bankTranRef;
	private String bankTranRef1;
	private String bankTranRef2;
	private String bankTranData;
	private String bankTranStatus;
	private String bankTranStatusDate;
	private String bankTranStatusTime;
	private double bankTranAmt1;
	private double bankTranAmt2;
	private double bankTranPayNo;
	private String bankTranDate;
	private String bankTranCreatedDate;
	private String bankTranCreatedTime;
	private boolean bankTranCredit;
	private String bankTranActive;
	
	public CompanyBankTran() {
		super();
	}

	public CompanyBankTran(long bankTranId, int bankCompId, int bankId, int bankTranType, String bankTranRef,
			String bankTranRef1, String bankTranRef2, String bankTranData, String bankTranStatus, String bankTranStatusDate,
			String bankTranStatusTime, double bankTranAmt1, double bankTranAmt2, double bankTranPayNo, String bankTranDate,
			String bankTranCreatedDate, String bankTranCreatedTime, boolean bankTranCredit, String bankTranActive) {
		super();
		this.bankTranId = bankTranId;
		this.bankCompId = bankCompId;
		this.bankId = bankId;
		this.bankTranType = bankTranType;
		this.bankTranRef = bankTranRef;
		this.bankTranRef1 = bankTranRef1;
		this.bankTranRef2 = bankTranRef2;
		this.bankTranData = bankTranData;
		this.bankTranStatus = bankTranStatus;
		this.bankTranStatusDate = bankTranStatusDate;
		this.bankTranStatusTime = bankTranStatusTime;
		this.bankTranAmt1 = bankTranAmt1;
		this.bankTranAmt2 = bankTranAmt2;
		this.bankTranPayNo = bankTranPayNo;
		this.bankTranDate = bankTranDate;
		this.bankTranCreatedDate = bankTranCreatedDate;
		this.bankTranCreatedTime = bankTranCreatedTime;
		this.bankTranCredit = bankTranCredit;
		this.bankTranActive = bankTranActive;
	}

	public long getBankTranId() {
		return bankTranId;
	}

	public void setBankTranId(long bankTranId) {
		this.bankTranId = bankTranId;
	}

	public int getBankCompId() {
		return bankCompId;
	}

	public void setBankCompId(int bankCompId) {
		this.bankCompId = bankCompId;
	}

	public int getBankId() {
		return bankId;
	}

	public void setBankId(int bankId) {
		this.bankId = bankId;
	}

	public int getBankTranType() {
		return bankTranType;
	}

	public void setBankTranType(int bankTranType) {
		this.bankTranType = bankTranType;
	}

	public String getBankTranRef() {
		return bankTranRef;
	}

	public void setBankTranRef(String bankTranRef) {
		this.bankTranRef = bankTranRef;
	}

	public String getBankTranRef1() {
		return bankTranRef1;
	}

	public void setBankTranRef1(String bankTranRef1) {
		this.bankTranRef1 = bankTranRef1;
	}

	public String getBankTranRef2() {
		return bankTranRef2;
	}

	public void setBankTranRef2(String bankTranRef2) {
		this.bankTranRef2 = bankTranRef2;
	}

	public String getBankTranData() {
		return bankTranData;
	}

	public void setBankTranData(String bankTranData) {
		this.bankTranData = bankTranData;
	}

	public String getBankTranStatus() {
		return bankTranStatus;
	}

	public void setBankTranStatus(String bankTranStatus) {
		this.bankTranStatus = bankTranStatus;
	}

	public String getBankTranStatusDate() {
		return bankTranStatusDate;
	}

	public void setBankTranStatusDate(String bankTranStatusDate) {
		this.bankTranStatusDate = bankTranStatusDate;
	}

	public String getBankTranStatusTime() {
		return bankTranStatusTime;
	}

	public void setBankTranStatusTime(String bankTranStatusTime) {
		this.bankTranStatusTime = bankTranStatusTime;
	}

	public double getBankTranAmt1() {
		return bankTranAmt1;
	}

	public void setBankTranAmt1(double bankTranAmt1) {
		this.bankTranAmt1 = bankTranAmt1;
	}

	public double getBankTranAmt2() {
		return bankTranAmt2;
	}

	public void setBankTranAmt2(double bankTranAmt2) {
		this.bankTranAmt2 = bankTranAmt2;
	}

	public double getBankTranPayNo() {
		return bankTranPayNo;
	}

	public void setBankTranPayNo(double bankTranPayNo) {
		this.bankTranPayNo = bankTranPayNo;
	}

	public String getBankTranDate() {
		return bankTranDate;
	}

	public void setBankTranDate(String bankTranDate) {
		this.bankTranDate = bankTranDate;
	}

	public String getBankTranCreatedDate() {
		return bankTranCreatedDate;
	}

	public void setBankTranCreatedDate(String bankTranCreatedDate) {
		this.bankTranCreatedDate = bankTranCreatedDate;
	}

	public String getBankTranCreatedTime() {
		return bankTranCreatedTime;
	}

	public void setBankTranCreatedTime(String bankTranCreatedTime) {
		this.bankTranCreatedTime = bankTranCreatedTime;
	}

	public boolean isBankTranCredit() {
		return bankTranCredit;
	}

	public void setBankTranCredit(boolean bankTranCredit) {
		this.bankTranCredit = bankTranCredit;
	}

	public String getBankTranActive() {
		return bankTranActive;
	}

	public void setBankTranActive(String bankTranActive) {
		this.bankTranActive = bankTranActive;
	}
	
	
		
}
