package za.co.payguru.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import za.co.payguru.model.CompanyProduct;

public class CompanyProductDao {
	
	public static CompanyProduct getCompanyProducts(int compId, int prodId, Connection connection){
		CompanyProduct companyProduct = new CompanyProduct();
		try(
				PreparedStatement statement = connection.prepareStatement("SELECT * FROM COMPANYPRODUCTS WHERE compid = ? AND prodid = ?");
		){
			statement.setInt(1, compId);
			statement.setInt(2, prodId);
			ResultSet rs = statement.executeQuery();
			if(rs.next()) {
				companyProduct.setProdId(rs.getInt("prodid"));
				companyProduct.setCompId(rs.getInt("compid"));
				companyProduct.setProdCode(rs.getString("prodcode"));
				companyProduct.setProdName(rs.getString("prodname"));
				companyProduct.setProdShortName(rs.getString("prodshortname"));
				companyProduct.setProdType(rs.getInt("prodType"));
				companyProduct.setProdTypeAmt1(rs.getDouble("prodtypeamt1"));
				companyProduct.setProdTypeAmt2(rs.getDouble("prodtypeamt2"));
				companyProduct.setProdTypeRsp(rs.getDouble("prodtypersp"));
				companyProduct.setProdTypeCost(rs.getDouble("prodtypecost"));
				companyProduct.setProdJoinName(rs.getString("prodjoinname"));
				companyProduct.setProdProRata(rs.getString("prodprorata"));
				companyProduct.setProdTypePay(rs.getInt("prodtypepay"));
				companyProduct.setProdTypeRebill(rs.getInt("prodtyperebill"));
				companyProduct.setProdTypeCycle(rs.getInt("prodtypecycle"));
				companyProduct.setProdStartDate(rs.getString("prodstartdate"));
				companyProduct.setProdEndDate(rs.getString("prodenddate"));
				companyProduct.setProdActive(rs.getString("prodactive"));
				companyProduct.setProdSmsMessage1(rs.getString("prodsmsmessage1"));
				companyProduct.setProdSmsDays1(rs.getInt("prodsmsdays1"));
				companyProduct.setProdSmsDays2(rs.getInt("prodsmsdays2"));
				companyProduct.setProdExtRef1(rs.getString("prodextref1"));
				companyProduct.setProdExtRef2(rs.getString("prodextref2"));
				companyProduct.setProdExtAmt1(rs.getDouble("prodextamt1"));
				companyProduct.setProdSmsMessage2(rs.getString("prodsmsmessage2"));
				companyProduct.setProdStruct(rs.getInt("prodstruct"));
				companyProduct.setProdStructAmt1(rs.getDouble("prodstructamt1"));
				companyProduct.setProdStructAmt2(rs.getDouble("prodstructamt2"));
				companyProduct.setProdSmsMessage3(rs.getString("prodsmsmessage3"));
				companyProduct.setCompInternalId(rs.getInt("compinternalid"));

			}rs.close();
		} catch(Exception e) {
			System.out.println("Error querying table : " + e.toString());
		}
		
		return companyProduct;
	} 
	
	public static ArrayList<CompanyProduct> getCompanyInternalProducts(int compId, int compInternalId, Connection connection){
		ArrayList<CompanyProduct> companyProducts = new ArrayList<CompanyProduct>();
		try(
				PreparedStatement statement = connection.prepareStatement("SELECT * FROM COMPANYPRODUCTS WHERE compid = ?" + (compInternalId==0 ? "" : " AND compinternalid = " + compInternalId));
		){
			statement.setInt(1, compId);
			System.out.println("\n\nSQL: " + statement.toString());
			ResultSet rs = statement.executeQuery();
			while(rs.next()) {
				CompanyProduct companyProduct = new CompanyProduct();
				companyProduct.setProdId(rs.getInt("prodid"));
				companyProduct.setCompId(rs.getInt("compid"));
				companyProduct.setProdCode(rs.getString("prodcode"));
				companyProduct.setProdName(rs.getString("prodname"));
				companyProduct.setProdShortName(rs.getString("prodshortname"));
				companyProduct.setProdType(rs.getInt("prodType"));
				companyProduct.setProdTypeAmt1(rs.getDouble("prodtypeamt1"));
				companyProduct.setProdTypeAmt2(rs.getDouble("prodtypeamt2"));
				companyProduct.setProdTypeRsp(rs.getDouble("prodtypersp"));
				companyProduct.setProdTypeCost(rs.getDouble("prodtypecost"));
				companyProduct.setProdJoinName(rs.getString("prodjoinname"));
				companyProduct.setProdProRata(rs.getString("prodprorata"));
				companyProduct.setProdTypePay(rs.getInt("prodtypepay"));
				companyProduct.setProdTypeRebill(rs.getInt("prodtyperebill"));
				companyProduct.setProdTypeCycle(rs.getInt("prodtypecycle"));
				companyProduct.setProdStartDate(rs.getString("prodstartdate"));
				companyProduct.setProdEndDate(rs.getString("prodenddate"));
				companyProduct.setProdActive(rs.getString("prodactive"));
				companyProduct.setProdSmsMessage1(rs.getString("prodsmsmessage1"));
				companyProduct.setProdSmsDays1(rs.getInt("prodsmsdays1"));
				companyProduct.setProdSmsDays2(rs.getInt("prodsmsdays2"));
				companyProduct.setProdExtRef1(rs.getString("prodextref1"));
				companyProduct.setProdExtRef2(rs.getString("prodextref2"));
				companyProduct.setProdExtAmt1(rs.getDouble("prodextamt1"));
				companyProduct.setProdSmsMessage2(rs.getString("prodsmsmessage2"));
				companyProduct.setProdStruct(rs.getInt("prodstruct"));
				companyProduct.setProdStructAmt1(rs.getDouble("prodstructamt1"));
				companyProduct.setProdStructAmt2(rs.getDouble("prodstructamt2"));
				companyProduct.setProdSmsMessage3(rs.getString("prodsmsmessage3"));
				companyProduct.setCompInternalId(rs.getInt("compinternalid"));
				companyProducts.add(companyProduct);
			}rs.close();
		} catch(Exception e) {
			System.out.println("Error querying table : " + e.toString());
		}
		
		return companyProducts;
	} 
	
	public static StringBuilder getCompanyProductsJSON(ArrayList<CompanyProduct> compProds) {
		StringBuilder sb = new StringBuilder();
		sb.append("[\n");
		for(int i=0;i<compProds.size();i++) {
			CompanyProduct compProd = compProds.get(i);
			sb.append("{\n");
			sb.append("\"compid\" : "+compProd.getCompId()+",\n");
			sb.append("\"prodid\" : "+compProd.getProdId()+",\n");
			sb.append("\"prodcode\" : \""+compProd.getProdCode()+"\",\n");
			sb.append("\"prodname\" : \""+compProd.getProdName()+"\",\n");
			sb.append("\"prodshortname\" : \""+compProd.getProdShortName()+"\",\n");
			sb.append("\"prodtype\" : "+compProd.getProdType()+",\n");
			sb.append("\"prodtypeamt1\" : "+compProd.getProdTypeAmt1()+",\n");
			sb.append("\"prodtypeamt2\" : "+compProd.getProdTypeAmt2()+",\n");
			sb.append("\"prodtypersp\" : "+compProd.getProdTypeRsp()+",\n");
			sb.append("\"prodtypecost\" : "+compProd.getProdTypeCost()+",\n");
			sb.append("\"prodjoinname\" : \""+compProd.getProdJoinName()+"\",\n");
			sb.append("\"prodprorata\" : \""+compProd.getProdProRata()+"\",\n");
			sb.append("\"prodtypepay\" : "+compProd.getProdTypePay()+",\n");
			sb.append("\"prodtyperebill\" : "+compProd.getProdTypeRebill()+",\n");
			sb.append("\"prodtypecycle\" : "+compProd.getProdTypeCycle()+",\n");
			sb.append("\"prodstartdate\" : \""+compProd.getProdStartDate()+"\",\n");
			sb.append("\"prodenddate\" : \""+compProd.getProdEndDate()+"\",\n");
			sb.append("\"prodactive\" : \""+compProd.getProdActive()+"\",\n");
			sb.append("\"prodsmsmessage1\" : \""+compProd.getProdSmsMessage1().replace("\"", "'")+"\",\n");
			sb.append("\"prodsmsdays1\" : "+compProd.getProdSmsDays1()+",\n");
			sb.append("\"prodsmsdays2\" : "+compProd.getProdSmsDays2()+",\n");
			sb.append("\"prodextref1\" : \""+compProd.getProdExtRef1()+"\",\n");
			sb.append("\"prodextref2\" : \""+compProd.getProdExtRef2()+"\",\n");
			sb.append("\"prodextamt1\" : "+compProd.getProdExtAmt1()+",\n");
			sb.append("\"prodsmsmessage2\" : \""+compProd.getProdSmsMessage2()+"\",\n");
			sb.append("\"prodstruct\" : "+compProd.getProdStruct()+",\n");
			sb.append("\"prodstructamt1\" : "+compProd.getProdStructAmt1()+",\n");
			sb.append("\"prodstructamt2\" : "+compProd.getProdStructAmt2()+",\n");
			sb.append("\"prodsmsmessage3\" : \""+compProd.getProdSmsMessage3()+"\",\n");
			sb.append("\"compinternalid\" : "+compProd.getCompInternalId()+"\n");
			sb.append("}"+(i==compProds.size()-1 ? "" : ",")+"\n");
		}
		sb.append("]");
		return sb;
	}
}
