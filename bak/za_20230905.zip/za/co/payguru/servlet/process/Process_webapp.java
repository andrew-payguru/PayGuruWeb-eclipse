package za.co.payguru.servlet.process;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.Date;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.json.JSONObject;

import za.co.payguru.dao.ClientInvoiceDao;
import za.co.payguru.dao.ClientInvoiceDataDao;
import za.co.payguru.dao.ClientPaymentDao;
import za.co.payguru.dao.CompanyBankDao;
import za.co.payguru.dao.CompanyDao;
import za.co.payguru.dao.CompanyInternalDao;
import za.co.payguru.dao.CompanyParamDao;
import za.co.payguru.dao.CompanyProductDao;
import za.co.payguru.dao.CompanySmsCampaignDao;
import za.co.payguru.dao.CompanySmsCampaignItemDao;
import za.co.payguru.dao.CompanySmsCustomerDao;
import za.co.payguru.dao.CompanySmsGroupCustomerDao;
import za.co.payguru.dao.CompanySmsGroupDao;
import za.co.payguru.dao.CompanyUserDao;
import za.co.payguru.dao.WebPageGroupDao;
import za.co.payguru.model.ClientInvoice;
import za.co.payguru.model.ClientInvoiceData;
import za.co.payguru.model.ClientPayment;
import za.co.payguru.model.Company;
import za.co.payguru.model.CompanyBank;
import za.co.payguru.model.CompanyInternal;
import za.co.payguru.model.CompanyParam;
import za.co.payguru.model.CompanyProduct;
import za.co.payguru.model.CompanySmsCampaign;
import za.co.payguru.model.CompanySmsCampaignItem;
import za.co.payguru.model.CompanySmsGroup;
import za.co.payguru.model.CompanyUser;
import za.co.payguru.model.WebPageGroup;
import za.co.payguru.util.DateUtil;
import za.co.payguru.util.HTTPUtil;
import za.co.payguru.util.JSONHelper;
import za.co.payguru.util.Util;

public class Process_webapp {

	public static final String SEARCH_ALL = "ALL";

	public static StringBuilder getCompanyParam(HttpServletRequest req, HttpServletResponse resp, JSONObject jsonBody, Connection connection) {
		StringBuilder sb = new StringBuilder();
		String errMsg = "";
		try {
			for(int z=0;z<1;z++) {
				int compid = JSONHelper.getIntValue(jsonBody, "compid");
				if(compid==0) {
					errMsg = "Invalid compid!";
					break;
				}
				Company company = CompanyDao.getCompany(compid, connection);
				if(company==null||company.getCompId()==0) {
					errMsg = "Company does not exist!";
					break;
				}
				String paramid = JSONHelper.getValue(jsonBody, "paramid");
				if(paramid==null||paramid.length()<=0) {
					errMsg = "Param ID invalid!";
					break;
				}
				CompanyParam compParam = CompanyParamDao.getParamValue(connection, compid, paramid);
				if(compParam==null||compParam.getParamid().length()<=0) {
					errMsg = "Company Parameter Invalid!";
					break;
				}
				sb = CompanyParamDao.getParamValueJSON(compParam);
			}
		}catch (Exception e) {
			System.out.println("Server Error Process: getCompanyPram -> " + e.toString());
			errMsg = "Server Error";
		}
		if(errMsg.length()>0) {
			resp.setStatus(HTTPUtil.HTTP_INTERNAL_SERVLET_ERROR);
			sb = JSONHelper.getErrorJson(errMsg);
		}
		return sb;
	}
	public static StringBuilder getSaleChannelInvoiceData(HttpServletRequest req, HttpServletResponse resp, JSONObject jsonBody, Connection connection) {
		StringBuilder sb = new StringBuilder();
		String errMsg = "";
		try {
			for(int z=0;z<1;z++) {
				int compid = JSONHelper.getIntValue(jsonBody, "compid");
				if(compid==0) {
					errMsg = "Invalid compid!";
					break;
				}
				Company company = CompanyDao.getCompany(compid, connection);
				if(company==null||company.getCompId()==0) {
					errMsg = "Company does not exist!";
					break;
				}
				String channel = JSONHelper.getValue(jsonBody, "channel");
				if(channel==null||channel.length()<=0) 
					channel = "ALL";

				int compinternalid = JSONHelper.getIntValue(jsonBody, "compinternalid");
				int prodid = JSONHelper.getIntValue(jsonBody, "prodid");

				String startDate = JSONHelper.getValue(jsonBody, "startdate");
				if(startDate==null||startDate.length()<=0) {
					errMsg = "Invalid start date";
					break;
				}
				String endDate = JSONHelper.getValue(jsonBody, "enddate");
				if(startDate==null||startDate.length()<=0) {
					errMsg = "Invalid end date";
					break;
				}
				ArrayList<ClientInvoiceData> clientInvoiceDatas = ClientInvoiceDataDao.getChannelClientInvoiceData(connection, compid, compinternalid, prodid, channel, startDate, endDate);
				sb = ClientInvoiceDataDao.getClientInvoiceDatasJSON(clientInvoiceDatas);
			}
		}catch (Exception e) {
			System.out.println("Server Error Process: getSaleChannelInvoiceData -> " + e.toString());
			errMsg = "Server Error";
		}
		if(errMsg.length()>0) {
			resp.setStatus(HTTPUtil.HTTP_INTERNAL_SERVLET_ERROR);
			sb = JSONHelper.getErrorJson(errMsg);
		}
		return sb;
	}

	public static StringBuilder getSaleChannelInvoiceDataSales(HttpServletRequest req, HttpServletResponse resp, JSONObject jsonBody, Connection connection) {
		StringBuilder sb = new StringBuilder();
		String errMsg = "";
		try {
			for(int z=0;z<1;z++) {
				int compid = JSONHelper.getIntValue(jsonBody, "compid");
				if(compid==0) {
					errMsg = "Invalid compid!";
					break;
				}
				Company company = CompanyDao.getCompany(compid, connection);
				if(company==null||company.getCompId()==0) {
					errMsg = "Company does not exist!";
					break;
				}
				String channel = JSONHelper.getValue(jsonBody, "channel");
				if(channel==null||channel.length()<=0) 
					channel = "ALL";

				int compinternalid = JSONHelper.getIntValue(jsonBody, "compinternalid");
				int prodid = JSONHelper.getIntValue(jsonBody, "prodid");
				int bankid = JSONHelper.getIntValue(jsonBody, "bankid");
				if(channel.equals("SMS")==false)
					bankid = 0;

				String startDate = JSONHelper.getValue(jsonBody, "startdate");
				if(startDate==null||startDate.length()<=0) {
					errMsg = "Invalid start date";
					break;
				}
				startDate = startDate.replace('-', '/');
				String endDate = JSONHelper.getValue(jsonBody, "enddate");
				if(startDate==null||startDate.length()<=0) {
					errMsg = "Invalid end date";
					break;
				}
				endDate = endDate.replace('-', '/');
				ArrayList<ClientInvoiceData> clientInvoiceDatas = ClientInvoiceDataDao.getChannelClientInvoiceDataSales(connection, compid, compinternalid, prodid, channel, startDate, endDate);
				if(bankid>0) {
					ArrayList<ClientInvoiceData> tmpInvoices = new ArrayList<ClientInvoiceData>();
					ArrayList<String> payrefs = ClientPaymentDao.getCompBankClientPayRefs(connection, compid, bankid, startDate, endDate);
					for(int i=0;i<clientInvoiceDatas.size();i++) {
						ClientInvoiceData data = clientInvoiceDatas.get(i);
						if(payrefs.indexOf(data.getInvNo())>=0) 
							tmpInvoices.add(data);
					}
					clientInvoiceDatas = tmpInvoices;
				}
				sb = ClientInvoiceDataDao.getClientInvoiceDatasJSON(clientInvoiceDatas);
			}
		}catch (Exception e) {
			System.out.println("Server Error Process: getSaleChannelInvoiceDataSales -> " + e.toString());
			errMsg = "Server Error";
		}
		if(errMsg.length()>0) {
			resp.setStatus(HTTPUtil.HTTP_INTERNAL_SERVLET_ERROR);
			sb = JSONHelper.getErrorJson(errMsg);
		}
		return sb;
	}
	public static StringBuilder getSaleChannelInvoices(HttpServletRequest req, HttpServletResponse resp, JSONObject jsonBody, Connection connection) {
		StringBuilder sb = new StringBuilder();
		String errMsg = "";
		try {
			for(int z=0;z<1;z++) {
				int compid = JSONHelper.getIntValue(jsonBody, "compid");
				if(compid==0) {
					errMsg = "Invalid compid!";
					break;
				}
				Company company = CompanyDao.getCompany(compid, connection);
				if(company==null||company.getCompId()==0) {
					errMsg = "Company does not exist!";
					break;
				}
				String channel = JSONHelper.getValue(jsonBody, "channel");
				if(channel==null||channel.length()<=0) 
					channel = "ALL";

				int compinternalid = JSONHelper.getIntValue(jsonBody, "compinternalid");
				int prodid = JSONHelper.getIntValue(jsonBody, "prodid");

				String startDate = JSONHelper.getValue(jsonBody, "startdate");
				if(startDate==null||startDate.length()<=0) {
					errMsg = "Invalid start date";
					break;
				}
				String endDate = JSONHelper.getValue(jsonBody, "enddate");
				if(startDate==null||startDate.length()<=0) {
					errMsg = "Invalid end date";
					break;
				}
				ArrayList<ClientInvoice> clientInvoices = ClientInvoiceDao.getChannelClientInvoices(connection, compid, compinternalid, prodid, channel, startDate, endDate);
				sb = ClientInvoiceDao.getClientInvoicesJSON(clientInvoices);
			}
		}catch (Exception e) {
			System.out.println("Server Error Process: getInvoiceChannelReport -> " + e.toString());
			errMsg = "Server Error";
		}
		if(errMsg.length()>0) {
			resp.setStatus(HTTPUtil.HTTP_INTERNAL_SERVLET_ERROR);
			sb = JSONHelper.getErrorJson(errMsg);
		}
		return sb;
	}

	public static StringBuilder getSaleChannelInvoiceSales(HttpServletRequest req, HttpServletResponse resp, JSONObject jsonBody, Connection connection) {
		StringBuilder sb = new StringBuilder();
		String errMsg = "";
		try {
			for(int z=0;z<1;z++) {
				int compid = JSONHelper.getIntValue(jsonBody, "compid");
				if(compid==0) {
					errMsg = "Invalid compid!";
					break;
				}
				Company company = CompanyDao.getCompany(compid, connection);
				if(company==null||company.getCompId()==0) {
					errMsg = "Company does not exist!";
					break;
				}
				String channel = JSONHelper.getValue(jsonBody, "channel");
				if(channel==null||channel.length()<=0) 
					channel = "ALL";

				int compinternalid = JSONHelper.getIntValue(jsonBody, "compinternalid");
				int prodid = JSONHelper.getIntValue(jsonBody, "prodid");
				int bankid = JSONHelper.getIntValue(jsonBody, "bankid");
				if(channel.equals("SMS")==false)
					bankid = 0;
				String startDate = JSONHelper.getValue(jsonBody, "startdate");
				if(startDate==null||startDate.length()<=0) {
					errMsg = "Invalid start date";
					break;
				}
				startDate = startDate.replace('-', '/');
				String endDate = JSONHelper.getValue(jsonBody, "enddate");
				if(startDate==null||startDate.length()<=0) {
					errMsg = "Invalid end date";
					break;
				}
				endDate = endDate.replace('-', '/');
				ArrayList<ClientInvoice> clientInvoices = ClientInvoiceDao.getChannelClientInvoiceSales(connection, compid, compinternalid, prodid, channel, startDate, endDate);
				System.out.println("INV sizes: " + clientInvoices.size());
				if(bankid>0) {
					ArrayList<ClientInvoice> tmpInvoices = new ArrayList<ClientInvoice>();
					ArrayList<String> payrefs = ClientPaymentDao.getCompBankClientPayRefs(connection, compid, bankid, startDate, endDate);
					for(int i=0;i<clientInvoices.size();i++) { 
						ClientInvoice inv = clientInvoices.get(i);
						System.out.println(inv.getInvNo());
						if(payrefs.indexOf(inv.getInvNo())>=0) {
							System.out.println("Matched");
							tmpInvoices.add(inv);
						}
					}
					clientInvoices = tmpInvoices;
				}
				sb = ClientInvoiceDao.getClientInvoicesJSON(clientInvoices);
				System.out.println(sb.toString());
			}
		}catch (Exception e) {
			System.out.println("Server Error Process: getInvoiceChannelReport -> " + e.toString());
			errMsg = "Server Error";
		}
		if(errMsg.length()>0) {
			resp.setStatus(HTTPUtil.HTTP_INTERNAL_SERVLET_ERROR);
			sb = JSONHelper.getErrorJson(errMsg);
		}
		return sb;
	}

	public static StringBuilder getCompanyInternals(HttpServletRequest req, HttpServletResponse resp, JSONObject jsonBody, Connection connection) {
		StringBuilder sb = new StringBuilder();
		String errMsg = "";
		try {
			for(int z=0;z<1;z++) {
				int compid = JSONHelper.getIntValue(jsonBody, "compid");
				if(compid==0) {
					errMsg = "Invalid compid!";
					break;
				}
				Company company = CompanyDao.getCompany(compid, connection);
				if(company==null||company.getCompId()==0) {
					errMsg = "Company does not exist!";
					break;
				}
				ArrayList<CompanyInternal> compInternals = CompanyInternalDao.loadCompanyInternals(connection, compid);
				sb = CompanyInternalDao.getCompanyInternalsJSON(compInternals);
			}
		}catch (Exception e) {
			System.out.println("Server Error Process: getCompanyInternals -> " + e.toString());
			errMsg = "Server Error";
		}
		if(errMsg.length()>0) {
			resp.setStatus(HTTPUtil.HTTP_INTERNAL_SERVLET_ERROR);
			sb = JSONHelper.getErrorJson(errMsg);
		}
		return sb;
	}
	public static StringBuilder getCompanyInternalProducts(HttpServletRequest req, HttpServletResponse resp,JSONObject jsonBody, Connection connection) {
		StringBuilder sb = new StringBuilder();
		String errMsg = "";
		try {
			for(int z=0;z<1;z++) {
				int compid = JSONHelper.getIntValue(jsonBody, "compid");
				if(compid==0) {
					errMsg = "Invalid compid!";
					break;
				}
				Company company = CompanyDao.getCompany(compid, connection);
				if(company==null||company.getCompId()==0) {
					errMsg = "Company does not exist!";
					break;
				}
				int compinternalid = JSONHelper.getIntValue(jsonBody, "compinternalid");
				ArrayList<CompanyProduct> companyProducts = CompanyProductDao.getCompanyInternalProducts(company.getCompId(), compinternalid, connection);
				sb = CompanyProductDao.getCompanyProductsJSON(companyProducts);
			}
		}catch (Exception e) {
			System.out.println("Server Error Process: getCompanyInternalProduct -> " + e.toString());
			errMsg = "Server Error";
		}
		if(errMsg.length()>0) {
			resp.setStatus(HTTPUtil.HTTP_INTERNAL_SERVLET_ERROR);
			sb = JSONHelper.getErrorJson(errMsg);
		}
		return sb;
	}
	
	public static StringBuilder getCompanyBanks(HttpServletRequest req, HttpServletResponse resp, JSONObject jsonBody, Connection connection) {
		StringBuilder sb = new StringBuilder();
		String errMsg = "";
		try {
			for(int z=0;z<1;z++) {
				int compid = JSONHelper.getIntValue(jsonBody, "compid");
				if(compid==0) {
					errMsg = "Invalid compid!";
					break;
				}
				Company company = CompanyDao.getCompany(compid, connection);
				if(company==null||company.getCompId()==0) {
					errMsg = "Company does not exist!";
					break;
				}
				ArrayList<CompanyBank> banks = CompanyBankDao.getCompanyBanks(connection, compid);
				sb = CompanyBankDao.getCompanyBankJSON(banks);
			}
		}catch (Exception e) {
			System.out.println("Server Error Process: getCompanyBanks -> " + e.toString());
			errMsg = "Server Error";
		}
		if(errMsg.length()>0) {
			resp.setStatus(HTTPUtil.HTTP_INTERNAL_SERVLET_ERROR);
			sb = JSONHelper.getErrorJson(errMsg);
		}
		return sb;
	}
}
